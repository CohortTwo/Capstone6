package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ntuc.model.Hotel;

public interface EnumInterface extends JpaRepository<Hotel, Integer> {

}
