package com.ntuc.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ntuc.model.Hotel;
import com.ntuc.repository.EnumInterface;



@Controller
public class EnumController {
	
	@Autowired
	EnumInterface repo;
	
//	@GetMapping("/new")
//	public String AddRoom() {
//		Hotel hotel = new Hotel();
//		hotel.setHotelname("RiverFront");
//		hotel.setRoomtype(RoomType.luxory);
//		repo.save(hotel);
//		return "index";
//	}
	
	@RequestMapping("/new")
	public String showNewRoom(Model model) {
		Hotel hotel = new Hotel();
		model.addAttribute("hotel", hotel);
		
		return "index";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("hotel") Hotel product) {
		repo.save(product);
		return "Success";
	}
}
