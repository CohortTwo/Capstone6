package com.ntuc.model;

public enum RoomType {
	Standard,
	Delux,
	luxory;
}
