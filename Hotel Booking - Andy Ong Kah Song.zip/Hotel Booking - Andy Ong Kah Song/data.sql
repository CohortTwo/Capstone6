INSERT INTO users VALUES(1,'andy','$2y$12$xCxSaGYEy6mdn/gQvFAx1uUnX3UgtnQTzF5k0RhWfiz7lG/i44yaq',true);
INSERT INTO users VALUES(2,'admin','$2y$12$kZMHg3ls2JjEIgM8AYtuNu2qp6SdXtvHfGq/LVFwXWiP/rZGW475y',true);
INSERT INTO roles VALUES(1,'admin');
INSERT INTO roles VALUES(2,'user');
INSERT INTO users_roles VALUES (1,2);
INSERT INTO users_roles VALUES (2,1);

INSERT INTO customers VALUES (4321, 'Andy', 'andyong17@gmail.com', '12341234', '789078907890', 1);

INSERT INTO room_types VALUES(1, 'Regular');
INSERT INTO room_types VALUES(2, 'VIP');

INSERT INTO rooms VALUES(1, 1); 
INSERT INTO rooms VALUES(2, 1);
INSERT INTO rooms VALUES(3, 1);
INSERT INTO rooms VALUES(4, 1);
INSERT INTO rooms VALUES(5, 1);
INSERT INTO rooms VALUES(6, 1);
INSERT INTO rooms VALUES(7, 1);
INSERT INTO rooms VALUES(8, 1);
INSERT INTO rooms VALUES(9, 1);
INSERT INTO rooms VALUES(10, 1);
INSERT INTO rooms VALUES(11, 1);
INSERT INTO rooms VALUES(12, 1);
INSERT INTO rooms VALUES(13, 1);
INSERT INTO rooms VALUES(14, 1);
INSERT INTO rooms VALUES(15, 1);
INSERT INTO rooms VALUES(16, 1);
INSERT INTO rooms VALUES(17, 1);
INSERT INTO rooms VALUES(18, 1);
INSERT INTO rooms VALUES(19, 1);
INSERT INTO rooms VALUES(20, 1);
INSERT INTO rooms VALUES(21, 1);
INSERT INTO rooms VALUES(22, 1);
INSERT INTO rooms VALUES(23, 1);
INSERT INTO rooms VALUES(24, 1);
INSERT INTO rooms VALUES(25, 1);
INSERT INTO rooms VALUES(26, 2);
INSERT INTO rooms VALUES(27, 2);
INSERT INTO rooms VALUES(28, 2);
INSERT INTO rooms VALUES(29, 2);
INSERT INTO rooms VALUES(30, 2);

INSERT INTO rates (rate_id, rate_per_day, start_date, end_date, room_type_id) VALUES(1, 200.00, '2012-03-24', '2012-04-24', 1);
INSERT INTO rates (rate_id, rate_per_day, start_date, end_date, room_type_id) VALUES(2, 400.00, '2012-03-24', '2012-04-24', 2);

INSERT INTO bookings(booking_id, customer_id) VALUES(5, 4321);

INSERT INTO rooms_bookings(room_id, booking_id, day) VALUES(20, 5, '2021-03-25');
INSERT INTO rooms_bookings(room_id, booking_id, day) VALUES(20, 5, '2021-03-26');

INSERT INTO invoices(invoice_id, invoice_date, customer_id) VALUES(1234, '2021-03-24', 1);

INSERT INTO bookings_invoices(booking_id, invoice_id) VALUES(5, 1234);
