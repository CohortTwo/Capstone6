CREATE TABLE IF NOT EXISTS room_types (
	room_type_id SERIAL PRIMARY KEY,
	room_type_name VARCHAR(15) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS rooms (
	room_id SERIAL PRIMARY KEY,
	room_type_id SERIAL,
	CONSTRAINT fk_room_types FOREIGN KEY(room_type_id) REFERENCES room_types(room_type_id)
);

CREATE TABLE IF NOT EXISTS rates (
	rate_id SERIAL PRIMARY KEY, 
	rate_per_day NUMERIC(6,2) NOT NULL,
	date_created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	start_date DATE, 
	end_date DATE,
	room_type_id SERIAL,
	CONSTRAINT fk_room_types FOREIGN KEY(room_type_id) REFERENCES room_types(room_type_id)
);

CREATE TABLE IF NOT EXISTS users (
  user_id SERIAL PRIMARY KEY,
  username varchar(45) NOT NULL UNIQUE,
  password varchar(150) NOT NULL,
  enabled boolean DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS customers (
	customer_id SERIAL PRIMARY KEY,
	name VARCHAR(50) NOT NULL,
	email VARCHAR(25),
	phone VARCHAR(15), 
	credit_card_no VARCHAR(16),
	user_id SERIAL,
	CONSTRAINT fk_user FOREIGN KEY(user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS invoices (
	invoice_id SERIAL PRIMARY KEY,
	invoice_date DATE NOT NULL,
	customer_id SERIAL,
	CONSTRAINT fk_customers FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE IF NOT EXISTS bookings (
	booking_id SERIAL PRIMARY KEY,
	date_booked TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
	customer_id SERIAL,
	CONSTRAINT fk_customers FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE IF NOT EXISTS bookings_invoices (
	booking_id SERIAL,
	invoice_id SERIAL, 
	CONSTRAINT fk_bookings FOREIGN KEY(booking_id) REFERENCES bookings(booking_id), 
	CONSTRAINT fk_invoices FOREIGN KEY(invoice_id) REFERENCES invoices(invoice_id)
);

CREATE TABLE IF NOT EXISTS rooms_bookings (
	room_id SERIAL,
	booking_id SERIAL, 
	day DATE, 
	CONSTRAINT fk_rooms FOREIGN KEY(room_id) REFERENCES rooms(room_id),
	CONSTRAINT fk_bookings FOREIGN KEY(booking_id) REFERENCES bookings(booking_id)
);


CREATE TABLE IF NOT EXISTS payments (
	payment_id SERIAL PRIMARY KEY,
	payment_date DATE NOT NULL, 
	description VARCHAR(150), 
	customer_id SERIAL, 
	CONSTRAINT fk_customers FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
);
	
CREATE TABLE IF NOT EXISTS invoices_payments (
	invoice_id SERIAL,
	payment_id SERIAL,
	CONSTRAINT fk_invoices FOREIGN KEY(invoice_id) REFERENCES invoices(invoice_id), 
	CONSTRAINT fk_payments FOREIGN KEY(payment_id) REFERENCES payments(payment_id)
);

CREATE TABLE IF NOT EXISTS roles (
  role_id SERIAL PRIMARY KEY,
  name varchar(45) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS users_roles (
  user_id SERIAL,
  role_id SERIAL,
  CONSTRAINT fk_user FOREIGN KEY(user_id) REFERENCES users(user_id), 
  CONSTRAINT fk_role FOREIGN KEY(role_id) REFERENCES roles(role_id)
);
