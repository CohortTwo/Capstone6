package andy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.common.collect.ArrayListMultimap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import java.time.LocalDate;

import andy.repository.JdbcBooking;

@SpringBootApplication
public class AndyApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = 
			SpringApplication.run(AndyApplication.class, args);

		JdbcBooking testBooking = ctx.getBean("jdbcBooking", JdbcBooking.class);


		//var tempList = new ArrayList<HashMap<String, Object>>();
		// testBooking.getVacantRoom(testBooking.findOne(31));

		/*
		testBooking.deleteById(27);
		testBooking.deleteById(28);
		testBooking.deleteById(29);
		testBooking.deleteById(30);
		*/

		/*
		var testInsert1 = new HashMap<String, Object>() {{
			put("custId", 4321 );
			put("roomId", 18);
			put("startDate", LocalDate.of(2021, 03, 26));
			put("endDate", LocalDate.of(2021, 03, 30));
		}};

		var testInsert2 = new HashMap<String, Object>() {{
			put("custId", 4321 );
			put("roomId", 17);
			put("startDate", LocalDate.of(2021, 03, 26));
			put("endDate", LocalDate.of(2021, 03, 30));
		}};

		var testInsert3 = new HashMap<String, Object>() {{
			put("custId", 4321 );
			put("roomId", 12);
			put("startDate", LocalDate.of(2021, 04, 1));
			put("endDate", LocalDate.of(2021, 04, 4));
		}};

		var testInsert4 = new HashMap<String, Object>() {{
			put("custId", 4321 );
			put("roomId", 3);
			put("startDate", LocalDate.of(2021, 03, 25));
			put("endDate", LocalDate.of(2021, 03, 26));
		}};
		testBooking.save(testInsert1);
		testBooking.save(testInsert2);
		testBooking.save(testInsert3);
		testBooking.save(testInsert4);
		*/
	}

}
