package andy.repository;

import java.util.HashMap;
import java.util.List;

import com.google.common.collect.ArrayListMultimap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JdbcRoomType 
	implements BasicRepository<HashMap<String, Object>> {

	private JdbcTemplate jdbc;

	@Autowired
	public JdbcRoomType(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public List<HashMap<String, Object>> findAll() {
		String sql = 
				"select " +
				"rt.room_type_id, " +
				"rt.room_type_name, " +
				"r.rate_per_day " +
				"from room_types AS rt " +
				"join rates AS r " + 
				"on rt.room_type_id = r.room_type_id";

		return jdbc.query(sql, (rs, rowNum) -> new HashMap<String, Object>() {{
			put("roomTypeId", rs.getString("room_type_id"));
			put("roomTypeName", rs.getString("room_type_name"));
			put("ratesPerDay", rs.getString("rate_per_day"));
		}});
	}
}
