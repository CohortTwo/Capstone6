package andy.repository;

import java.util.List;

public interface BasicRepository<T> {
	List<T> findAll();
}
