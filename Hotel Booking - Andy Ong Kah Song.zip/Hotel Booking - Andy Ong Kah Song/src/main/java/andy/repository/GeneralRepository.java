package andy.repository;

public interface GeneralRepository<T> 
	extends BasicRepository<T> {

//	List<T> findAll();

	T findOne(Integer id);

	T save(T record);

	void deleteById(Integer id);

	T update(T record);
}
