package andy.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class JdbcBooking implements GeneralRepository<HashMap<String, Object>> {
	private JdbcTemplate jdbc;

	final private String SQL_GET_ALL_BOOKINGS =
			"select b.booking_id, " +
			"c.customer_id, " +
			"c.name, " +
			"rb.room_id, " +
			"rb.day, " +
			"rt.room_type_name, " +
			"r.room_type_id, " +
			"ra.rate_per_day " +
			"from bookings AS b " + 
			"join customers AS c " +
			"on b.customer_id = c.customer_id "  +
			"join rooms_bookings AS rb "  +
			"on rb.booking_id = b.booking_id "  +
			"join rooms AS r "  +
			"on rb.room_id = r.room_id " +
			"join room_types AS rt " +
			"on r.room_type_id = rt.room_type_id " +
			"join rates AS ra " +
			"on rt.room_type_id = ra.room_type_id ";

	@Autowired
	public JdbcBooking(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override 
	public List<HashMap<String, Object>> findAll() {
		String sql = SQL_GET_ALL_BOOKINGS + "order by rb.day asc ";
		return packBookings( jdbc.query(sql, this::mapRowToBookings));
	}

	@Override
	public HashMap<String, Object> findOne(Integer bookingId) {
		String sql =
			SQL_GET_ALL_BOOKINGS + 
			"where b.booking_id= ? " +
			"order by rb.day asc ";
		return packBookings(jdbc.query(sql, this::mapRowToBookings, bookingId)).get(0);
	}

	@Override
	@Transactional
	public HashMap<String, Object> save(HashMap<String, Object> booking) {

		KeyHolder keyHolder = new GeneratedKeyHolder();
		String sqlBooking = "insert into bookings (customer_id) values (?) ";
		var unPackedBooking = unPackBookings(booking);

		jdbc.update(conn -> {
			PreparedStatement ps = 
				conn.prepareStatement(sqlBooking, new String[] {"booking_id"});
			ps.setInt(1, (Integer) booking.get("custId"));
			return ps;
		}, keyHolder);

		String sqlDetails = 
			"insert into rooms_bookings " +
			"(room_id, booking_id, day) " + 
			"values (?, ?, ?) ";

		jdbc.batchUpdate(sqlDetails, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) 
				throws SQLException {

				Integer bookingId = (Integer) keyHolder.getKey();
				ps.setInt(1, (Integer) booking.get("roomId"));
				ps.setInt(2, (Integer) bookingId);
				ps.setObject(3, unPackedBooking.get(i).get("day"));
			}

			@Override
			public int getBatchSize() {
				return unPackedBooking.size();
			}
		});
		return booking;
	}

	@Override
	@Transactional
	public void deleteById(Integer bookingId) {
		String sqlRoomsBookings = 
			"delete from rooms_bookings " +
			"where booking_id = ?";
		String sqlBookings = "delete from bookings where booking_id = ?";
		jdbc.update(sqlRoomsBookings, bookingId);
		jdbc.update(sqlBookings, bookingId);
	}

	public HashMap<String, Object> update(HashMap<String, Object> record) {
		return new HashMap<String, Object>();
	}

	private HashMap<String, Object> mapRowToBookings(
		ResultSet rs, int rowNum) throws SQLException {

		SimpleDateFormat formatter = 
			new SimpleDateFormat("yyyy-MM-dd");

		return new HashMap<String, Object>() {{
			put("bookingId", rs.getInt("booking_id"));
			put("custId", rs.getInt("customer_id"));
			put("roomId", rs.getString("room_id"));
			put("day", LocalDate.parse(formatter.format(rs.getDate("day"))));
			put("roomTypeName", rs.getString("room_type_name"));
			put("roomTypeId", rs.getInt("room_type_Id"));
			put("ratePerDay", rs.getString("rate_per_day"));
		}};
	}
	
	public List<HashMap<String, Object>> packBookings( 
			List<HashMap<String, Object>> rawMap) {

		// Get all unique bookingId and put them in list
		List<Integer> uniqueBookingId = new ArrayList<Integer>();

		for (HashMap<String, Object> map : rawMap) 
				uniqueBookingId.add( (Integer) map.get("bookingId") );

		uniqueBookingId = uniqueBookingId
			.stream()
			.distinct()
			.collect(Collectors.toList());
		
		// for every unique bookingId 
		List<HashMap<String, Object>> newList = 
			new ArrayList<HashMap<String, Object>>();

		for (int id : uniqueBookingId) {
			// from rawMap take take all the mutimaps whose bookingId = id
			// That will give you a list of record with the same bookingId 
			List<HashMap<String, Object>> group = 
				rawMap
					.stream() 
					.filter(e -> e.get("bookingId").equals(id))
					.collect(Collectors.toList());

			// Get the start and end date and put them in LocalDate variables
			LocalDate startDate = (LocalDate) group.get(0).get("day"); 
			LocalDate endDate = (LocalDate) group.get(group.size() -1 ).get("day");

			// Declare a new hashmap and put the packed data into it  
			var packedMap = new HashMap<String, Object>() {{
				put("bookingId", id);
				put("custId", group.get(0).get("custId"));
				put("roomId", group.get(0).get("roomId"));
				put("roomTypeName", group.get(0).get("roomTypeName"));
				put("roomTypeId", group.get(0).get("roomTypeId"));
				put("ratePerDay", group.get(0).get("ratePerDay"));
				put("startDate", startDate);
				put("endDate", endDate);
			}};

			// Finally, add the multimap into the new list you want to return
			newList.add(packedMap);
		}
		return newList;
	}

	public List<HashMap<String, Object>> unPackBookings(
			HashMap<String, Object> booking ) {

		LocalDate startDate = (LocalDate) booking.get("startDate");
		LocalDate endDate = (LocalDate) booking.get("endDate");
		List<LocalDate> dates = startDate
			.datesUntil(endDate.plusDays(1))
			.collect(Collectors.toList());

		var resultList = new ArrayList<HashMap<String, Object>>(); 

		for (LocalDate day : dates) {
			resultList.add(new HashMap<String, Object>() {{
				put("bookingId", booking.get("bookingId"));
				put("custId", booking.get("custId"));
				put("roomId", booking.get("roomId"));
				put("day", day);
				put("roomTypeName", booking.get("roomTypeName"));
				put("roomTypeId", booking.get("roomTypeId"));
				put("ratePerDay", booking.get("ratePerDay"));
			}});
		}
		return resultList;
	}

	public int getCustId(String username) {
		String sql = 
			"select c.customer_id from customers AS c " +
			"where c.user_id = " +
				"(select user_id from users AS u " +
				" where u.username = '%s') ";

		return jdbc.queryForObject(String.format(sql, username), Integer.class);
	}

	public Integer getVacantRoom(HashMap<String, Object> booking) {
		
		// Change booking to form where you can access to individual days
		var unPackedBookings = unPackBookings(booking);

		String sql = 
			"select room_id from rooms " + 
			"where room_type_id = %s and " +
			"room_id not in " +
			"(select distinct room_id from rooms_bookings where day in (%s))";

		// Prepare booking dates into a "('date1', 'date2', 'date3')" format so
		// that they can be inserted into the sql query string
		var tempList = new ArrayList<String>();
		for (int i = 0; i < unPackedBookings.size() ; i++)
			tempList.add(i, String.format("'%s'", unPackedBookings.get(i).get("day").toString()));
		var resultString = String.join(", ", tempList); 

		// Get roomTypeId for inclusion in sql query string
		var roomTypeId = booking.get("roomTypeId");

		// Execute query 
		var resultList = jdbc.queryForList(String.format(sql, roomTypeId, resultString));

		return resultList.isEmpty() ? -1 : (Integer) resultList.get(0).get("room_Id");
	}


}
// When dealing multiple room bookings!!!
//
// (1) get a set with all the VALUES for bookingId.
// (2) build a new HashMap : the following task have to be completed
// 		- Key and value of bookingId and custId
// 		- For each HashMap key and value of roomId, day,
// 		roomTypeName, and ratePerDay should go into the list under a
// 		"room" key
// (3) Ensure that the bookings are retrived in the right order. Namely,
// 'roomId' followed by 'day'
// (4) The packed HashMap goes into another List. 

