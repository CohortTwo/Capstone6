package andy;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired 
	DataSource dataSource;

	@Override
	public void configure(AuthenticationManagerBuilder auth) 
		throws Exception {

		JdbcUserDetailsManager jdbcUserDetailsService 
			= new JdbcUserDetailsManager(dataSource);

		String authsByUserQuery = 
			"select u.username, r.name " +
			"from users_roles as ur " +
			"join users as u on u.user_id=ur.user_id " +
			"join roles as r on r.role_id=ur.role_id " +
			"where username = ?";

		jdbcUserDetailsService.setAuthoritiesByUsernameQuery(authsByUserQuery);

		auth.userDetailsService(jdbcUserDetailsService)
			.passwordEncoder(new BCryptPasswordEncoder());
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(
				"/resources/**", 
				"/css/**",
				"/images/**", 
				"/fonts/**", 
				"/icon/**",
				"/vendor/**");
	}

	@Override 
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			.anyRequest().authenticated()
		.and()
			.formLogin().permitAll()
			.loginProcessingUrl("/authenticate").permitAll()
			.defaultSuccessUrl("/bookings", true)
		.and()
			.logout()
				.invalidateHttpSession(true)
				.deleteCookies("JSESSIONID")
				.permitAll();
	}
}
