package andy.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import andy.repository.JdbcBooking;
import andy.repository.JdbcRoomType;

@Controller
public class BookingController {

	@Autowired
	private JdbcBooking bookingRepo; 
	@Autowired
	private JdbcRoomType roomTypeRepo; 

	@GetMapping("/bookings") 
	public String listBookings(Model model) {
		List<HashMap<String, Object>> listBookings = bookingRepo.findAll();
		model.addAttribute("listBookings", listBookings);
		return "bookings";
	}

	@GetMapping("/bookings/new")
	public String newBooking(Model model, Authentication authentication) {

		List<HashMap<String, Object>> listRoomTypes = roomTypeRepo.findAll();
		List<HashMap<String, Object>> listBookings = bookingRepo.findAll();

		String username = authentication.getName();
		String custId = String.valueOf(bookingRepo.getCustId(username));

		model.addAttribute("listRoomTypes",listRoomTypes);
		model.addAttribute("listBookings", listBookings);
		model.addAttribute("custId", custId);
		return "booking_form";
	}

	@PostMapping("/bookings/confirm")
	public String confirm(
			Model model, 
			@RequestParam String roomTypeId, 
			@RequestParam String startDate,
			@RequestParam String endDate, 
			HttpSession session,
			Authentication authentication) {

		String username = authentication.getName();
		Integer custId = bookingRepo.getCustId(username);

		HashMap<String, Object> roomTypeMap = roomTypeRepo
			.findAll().get(Integer.parseInt(roomTypeId)-1);

		session.setAttribute("custId", custId);
		session.setAttribute("roomTypeId", roomTypeId);
		session.setAttribute("startDate", startDate);
		session.setAttribute("endDate", endDate);
		session.setAttribute("ratesPerDay", roomTypeMap.get("ratesPerDay"));
		session.setAttribute("roomTypeName", roomTypeMap.get("roomTypeName"));

		return "confirm";
	}

	@PostMapping("/bookings/save")
	public String saveBooking(Model model, 
			Authentication authentication, HttpSession session) {

		var newBooking = new HashMap<String, Object>() {{
			put("custId", session.getAttribute("custId"));
			put("roomId", session.getAttribute("roomId"));
			put("startDate", LocalDate.parse((String) session.getAttribute("startDate")));
			put("endDate", LocalDate.parse((String) session.getAttribute("endDate")));
			put("roomTypeId", session.getAttribute("roomTypeId"));
			put("ratePerDay", session.getAttribute("ratesPerDay"));
		}};

		Integer roomTypeId = bookingRepo.getVacantRoom(newBooking);
		newBooking.replace("roomId", roomTypeId);

		bookingRepo.save(newBooking);
		return "redirect:/bookings";
	}
}
