package com.hotel.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Room {
	@Id
	private Integer roomid;
	private String roomtype;
	@OneToMany(mappedBy ="roomnumber", cascade = CascadeType.ALL)
	private List<Roominfo> roomschedule = new ArrayList<>();

	public Room() {

	}

	public Room(Integer roomid, String roomtype, List<Roominfo> roomschedule) {
		this.roomid = roomid;
		this.roomtype = roomtype;
		this.roomschedule = roomschedule;
	}

	public void addDetail(Date value) {
		this.roomschedule.add(new Roominfo(value, this));

	}

	public String getRoomtype() {
		return roomtype;
	}

	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}

	public Integer getRoomid() {
		return roomid;
	}

	public void setRoomid(Integer roomid) {
		this.roomid = roomid;
	}

	@Override
	public String toString() {
		return "" + roomid;
	}

	public List<Roominfo> getRoomschedule() {
		return roomschedule;
	}

	public void setRoomschedule(List<Roominfo> roomschedule) {
		this.roomschedule = roomschedule;
	}
}
