package com.hotel.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Reservedate {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer datedetailid;
	
	@DateTimeFormat(pattern = "d-M-yyyy")
	private Date reserveddate;
	
	@ManyToOne
	@JoinColumn
	private Reservation datedetail;

	public Reservedate(Date reserveddate, Reservation datedetail) {
		this.reserveddate = reserveddate;
		this.datedetail = datedetail;
	}

	public Reservedate() {

	}

	public Reservedate(Integer datedetailid, Date reserveddate, Reservation datedetail) {
		this.datedetailid = datedetailid;
		this.reserveddate = reserveddate;
		this.datedetail = datedetail;
	}

	@Override
	public String toString() {
		SimpleDateFormat formatter = new SimpleDateFormat("d-M-yyyy");
		String blkDate= formatter.format(reserveddate);
	 		return  blkDate;
	}
	
	public Integer getDatedetailid() {
		return datedetailid;
	}

	public void setDatedetailid(Integer datedetailid) {
		this.datedetailid = datedetailid;
	}

	public Date getReserveddate() {
		return reserveddate;
	}

	public void setReserveddate(Date reserveddate) {
		this.reserveddate = reserveddate;
	}

	public Reservation getDatedetail() {
		return datedetail;
	}

	public void setDatedetail(Reservation datedetail) {
		this.datedetail = datedetail;
	}
}
