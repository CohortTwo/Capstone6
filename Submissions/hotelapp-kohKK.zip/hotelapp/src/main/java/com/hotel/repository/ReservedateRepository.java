package com.hotel.repository;

import java.util.Date;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hotel.model.Reservedate;

public interface ReservedateRepository extends JpaRepository<Reservedate, Integer> {
	@Query(value = "select reserveddate from Reservedate", nativeQuery = true)
    Date[] showDates();
}
