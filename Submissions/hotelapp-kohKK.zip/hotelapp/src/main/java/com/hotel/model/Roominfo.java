package com.hotel.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Component
public class Roominfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer roombookid;
	
	@DateTimeFormat(pattern = "d-M-yyyy")
	private Date bookdate;
	
	@ManyToOne
	@JoinColumn
	private Room roomnumber;

	public Roominfo(Date bookdate, Room roomnumber) {
		this.bookdate = bookdate;
		this.roomnumber = roomnumber;
	}
	
	public Roominfo() {

	}
	
	public Roominfo(Integer roombookid, Date bookdate, Room roomnumber) {
		this.roombookid = roombookid;
		this.bookdate = bookdate;
		this.roomnumber = roomnumber;
	}
	public Integer getRoombookid() {
		return roombookid;
	}
	public void setRoombookid(Integer roombookid) {
		this.roombookid = roombookid;
	}
	public Date getBookdate() {
		return bookdate;
	}
	public void setBookdate(Date bookdate) {
		this.bookdate = bookdate;
	}
	public Room getRoomnumber() {
		return roomnumber;
	}
	public void setRoomnumber(Room roomnumber) {
		this.roomnumber = roomnumber;
	}
}
