package com.hotel.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Reservation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer reserveid;

	private String guestid;
	
	@ManyToOne
	@JoinColumn(name= "roomid")
	private Room roomobj;
	
	@OneToMany(mappedBy ="datedetail", cascade = CascadeType.ALL)
	private List<Reservedate> datedetails = new ArrayList<>();

	public void addDetail(Date value) {
		this.datedetails.add(new Reservedate(value,this));

	}

	public Reservation() {

	}

	public Reservation(Integer reserveid, String guestid, Room roomobj, List<Reservedate> datedetails) {
		this.reserveid = reserveid;
		this.guestid = guestid;
		this.roomobj = roomobj;
		this.datedetails = datedetails;
	}

	public Room getRoomobj() {
		return roomobj;
	}

	public void setRoomobj(Room roomobj) {
		this.roomobj = roomobj;
	}

	public Integer getReserveid() {
		return reserveid;
	}

	public void setReserveid(Integer reserveid) {
		this.reserveid = reserveid;
	}

	public String getGuestid() {
		return guestid;
	}

	public void setGuestid(String guestid) {
		this.guestid = guestid;
	}

	public List<Reservedate> getDatedetails() {
		return datedetails;
	}

	public void setDatedetails(List<Reservedate> datedetails) {
		this.datedetails = datedetails;
	}
}
