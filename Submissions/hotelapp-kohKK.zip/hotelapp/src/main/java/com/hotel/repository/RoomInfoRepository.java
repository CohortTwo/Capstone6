package com.hotel.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hotel.model.Room;
import com.hotel.model.Roominfo;

public interface RoomInfoRepository extends JpaRepository<Roominfo, Integer>  {
	@Query(value = "select bookdate from Roominfo", nativeQuery = true)
    Date[] showDates();
	
	@Query("Select bookdate From Roominfo Where roomnumber=?1")
    Date[] showDatesByRoom(Room roomnumber);

	@Query("Select bookdate From Roominfo Where roomnumber= :roomnumber AND bookdate Between :startDate AND :endDate")
	Date[] showDatesByRoomDate(@Param("roomnumber") Room roomnumber, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
	
	@Query("Select Distinct roomnumber From Roominfo Where bookdate Between :startDate AND :endDate")
	List<Room> showRoomsByRoomDate(@Param("startDate") Date startDate, @Param("endDate") Date endDate);

}
