package com.hotel.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import com.hotel.model.Reservation;
import com.hotel.model.Room;
import com.hotel.repository.ReservationRepository;
import com.hotel.repository.RoomInfoRepository;
import com.hotel.repository.RoomRepository;

@Controller
public class ReservationController implements WebMvcConfigurer {
	@Autowired
	private RoomRepository roomRepo;
	@Autowired
	private ReservationRepository resRepo;
	@Autowired
	private RoomInfoRepository roomResRepo;

	@GetMapping("/")
	public String showMain(Model model) {
		List<Room> listRooms = roomRepo.findAll();
		model.addAttribute("listRooms", listRooms);
		return "index";
	}

	@GetMapping("/queryroomavailable")
	public String queryRoomAvailable(Model model) {

		return "roomavailable.html";
	}

	@GetMapping("/roomavailable/result")
	public String showRoomAvailable(HttpServletRequest request, Model model) {
		String[] startDates = request.getParameterValues("startDate");
		String[] endDates = request.getParameterValues("endDate");

		try {
			Date startDate = new SimpleDateFormat("yyyy-M-d").parse(startDates[0]);
			Date endDate = new SimpleDateFormat("yyyy-M-d").parse(endDates[0]);

			DateFormat dateFormat = new SimpleDateFormat("dd-M-yyyy");
			String strDateStart = dateFormat.format(startDate);
			String strDateEnd = dateFormat.format(endDate);

			Date startD = new SimpleDateFormat("d-M-yyyy").parse(strDateStart);
			Date endD = new SimpleDateFormat("d-M-yyyy").parse(strDateEnd);
			
System.out.println("1");
			List<Room> listNotAvailableRooms = roomResRepo.showRoomsByRoomDate(startD, endD);
System.out.println("2");

			List<Room> listAvailableRooms = roomRepo.findAll();
			
			System.out.println("size before : " + listAvailableRooms.size());
			
			listAvailableRooms.removeAll(listNotAvailableRooms);
			
			System.out.println("size after : " + listAvailableRooms.size());

			if (listAvailableRooms.size() > 0) {
				for (int i = 0; i < listAvailableRooms.size(); i++) {
					model.addAttribute("listRooms", listAvailableRooms);
					model.addAttribute("startdate", strDateStart);
					model.addAttribute("enddate", strDateEnd);
					return "roomdatesavailable";
				}
			} else {
				return "notavailable.html";
			}

			return "index";
		} catch (Exception e) {
			return "error";
		}
	}

	@GetMapping("/reservation/{roomid}")
	public String roomReserveForm(@PathVariable(name = "roomid") Integer roomid, Model model) {
		Room r = roomRepo.findRoomInfo(roomid);
		model.addAttribute("rid", roomid);

		Reservation reserve = new Reservation();
		model.addAttribute("reserve", reserve);
		Date[] bookeddates = roomResRepo.showDatesByRoom(r);
		String[] bookDates = new String[bookeddates.length];
		SimpleDateFormat sdf = new SimpleDateFormat("d-M-yyyy");

		for (int i = 0; i < bookeddates.length; i++) {
			bookDates[i] = sdf.format(bookeddates[i]);
		}
		model.addAttribute("bookdates", bookDates);
		return "roomreservehtml";
	}

	public static Date addDays(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // minus number would decrement the days
		return cal.getTime();
	}

	@PostMapping("/reservation/roomsave")
	public String saveRoomReservation(Reservation reserve, Room room, HttpServletRequest request) {
		String[] resDate = request.getParameterValues("reserveddate");

		try {
			String[] roomIDs = request.getParameterValues("roomobj");
			Room rom = roomRepo.findRoomInfo(Integer.parseInt(roomIDs[0]));

			String[] nosDaystr = request.getParameterValues("nods");
			int nosDays = Integer.parseInt(nosDaystr[0]);

			Date startDate = new SimpleDateFormat("dd-MM-yyyy").parse(resDate[0]);
			Date endDate = addDays(startDate, nosDays - 1);

			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String strDateStart = dateFormat.format(startDate);
			String strDateEnd = dateFormat.format(endDate);

			System.out.println("\n\n\n\nstrDate : " + strDateStart + " ||||| " + strDateEnd);

			Date[] alreadyBookDate = roomResRepo.showDatesByRoomDate(rom, startDate, endDate);

			for (int i = 0; i < alreadyBookDate.length; i++) {
				System.out.println("\n\n\nDateB = " + alreadyBookDate[i]);
			}
			
			System.out.println("\n>\n>\n>\nalreadyBookDate Length " + alreadyBookDate.length);	// empty Date[] array can print but empty Room[] array cannot???

			if (alreadyBookDate.length > 0) {
				return "notavailable.html";
			}

			// Alternative method but will be time consuming process (high payload)
//			Date[] blockDates = roomResRepo.showDatesByRoom(rom)			
//			for(int i=0; i<nosDays; i++) {
//				for(int j=0; j<blockDates.length; j++) {
//					Date d = new SimpleDateFormat("dd-MM-yyyy").parse(resDate[0]);
//					Date addDate = addDays(d, i);
//					if(addDate.equals(blockDates[j])) {
//						return "notavailable.html";
//					}
//				}
//			}

			for (int i = 0; i < nosDays; i++) {
				Date d = new SimpleDateFormat("dd-MM-yyyy").parse(resDate[0]);
				Date addDate = addDays(d, i);
				reserve.addDetail(addDate);
				resRepo.save(reserve);
				rom.addDetail(addDate);
				roomRepo.save(rom);
			}
			return "redirect:/";
		} catch (Exception e) {
			return "redirect:/error.html";
		}
	}
}
