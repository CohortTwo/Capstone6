package com.hotel.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.hotel.model.Room;

public interface RoomRepository extends JpaRepository<Room, Integer> {
	@Query("Select r From Room r")
	public List<Room> findAll();
	
	@Query("Select r From Room r Where roomid=?1")
	public Room findRoomInfo(Integer roomid); 
}
