Can use
a@hotmail.com or b@hotmail.com or c@hotmail.com
password: pass

https://cheongsisienhotelcp6.herokuapp.com/