// process live cost price of reservation form

$('.form-group').on('input', 'input',  '.prc', function () {
	// use '' to bring up choice of onkeypress, onchange, oninput etc..

  var totalPrice = 0;
  var counter = 1;
  var numberofchild = (numberofchild === undefined) ? 0 : numberofchild;
  var numberofbuffet = (numberofbuffet === undefined) ? 0 : numberofbuffet;
  var number_of_days = (number_of_days === undefined) ? 0 : number_of_days;

  $('.form-group .prc').each(function () {
    var inputVal = $(this).val();

    if (inputVal.includes("Single")) {
        totalPrice = 388;}
    
    if (inputVal.includes("Double")) {
        totalPrice = 488;}
        
    if (inputVal.includes("Family")) {
        totalPrice = 888;}
       
    if (inputVal.includes("Honeymoon")) {
        totalPrice = 1888;}
    

    
    numberofchild = +document.getElementById('child_number').value;
    numberofbuffet = +document.getElementById('res_buffet').value;
    var dateI1 = document.getElementById("dateTime_arr").value;  
    var dateI2 = document.getElementById("dateTime_end").value;  

    var date1 = new Date(dateI1);  
    var date2 = new Date(dateI2);
    var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
    number_of_days = Math.round(Math.abs((date2.getTime() - date1.getTime()) / (oneDay)));
    console.log('number of days, child and price');
    console.log(number_of_days);
    console.log(numberofchild); 
    console.log(totalPrice);
    console.log("counter");
    console.log(counter);

  });

  totalPrice = (totalPrice * number_of_days) + (numberofchild * 50) + (numberofbuffet * 30);
   if (totalPrice > 0) {
   document.getElementById('priceField').value = totalPrice;
  $('#price-count').text(totalPrice); }
 

});

