package com.hresource.repository;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

public class RoomId implements Serializable {

    private String roomType;
    private LocalDate roomDate;

    public RoomId() {
    }

    public RoomId(String roomType , LocalDate roomDate) {
        this.roomType = roomType;
        this.roomDate = roomDate;
    }

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public LocalDate getRoomDate() {
		return roomDate;
	}

	public void setRoomDate(LocalDate roomDate) {
		this.roomDate = roomDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((roomType == null) ? 0 : roomType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoomId other = (RoomId) obj;
		if (roomType == null) {
			if (other.roomType != null)
				return false;
		} else if (!roomType.equals(other.roomType))
			return false;
		return true;
	}






}

