package com.hresource.controller;

import java.util.Date;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SessionController {
	
	@GetMapping("/")
	public String ShowFirst(HttpSession session) {
		Object date=new Date();
		String test = "Good Morning";
		session.setAttribute("today", date);
		session.setAttribute("test", test);
		return "index";
	}
	
	@GetMapping("/page1")
	public String NextPage() {
		return "page1";
	}
	
	@GetMapping("/page2")
	public String OneMorePage(@RequestParam("p2") String p1,HttpSession session) {
		session.setAttribute("p1", p1);
		return "page2";
	}

}
