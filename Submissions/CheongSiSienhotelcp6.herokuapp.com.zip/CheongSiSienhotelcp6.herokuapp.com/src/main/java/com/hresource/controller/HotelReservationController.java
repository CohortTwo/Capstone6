package com.hresource.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hresource.model.Bookedroom;
import com.hresource.repository.*;

import com.hresource.service.ReservationService;
import com.hresource.service.UserService;
import com.hresource.temp.CurrentReservation;
import com.hresource.temp.CurrentUser;
import javax.servlet.http.HttpSession;



@Controller
public class HotelReservationController {
	 
	private UserService userService;

	private ReservationService reservationService;
	
	private BookedroomRep bookedroomRepository;
	
	@Autowired
	public HotelReservationController(UserService userService, ReservationService reservationService,BookedroomRep bookedroomRepository) {
		this.userService = userService;
		this.reservationService = reservationService;
		this.bookedroomRepository = bookedroomRepository;
		}

	// data binder
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
	}

	// home page
	@RequestMapping("/")
	public String homePage() {

		return "index";
	}

	
	// registration process page
	@PostMapping("/processRegistration")
	public String processRegistrationForm(@Valid @ModelAttribute("newUser") CurrentUser currentUser,
			BindingResult theBindingResult, Model model) {

		// check the database if user already exists
		if (userService.findUserByEmail(currentUser.getEmail()) != null) {
			model.addAttribute("newUser", new CurrentUser());
			model.addAttribute("registrationError", "Email already exists.");

			return "login";
		}

		// create user account
		userService.saveUser(currentUser);
		model.addAttribute("registrationSuccess", "registration Success.");

		return "redirect:/login-form-page";

	}

	// booking page
	@GetMapping("/new-reservation")
	public String newReservation(Model model) {
		// reservation attribute
		model.addAttribute("newRes", new CurrentReservation());
		
		return "reservation";
	}

	// save new reservation
	@PostMapping("/proceed-reservation")
	public String proceedReservation(@Valid @ModelAttribute("newRes") CurrentReservation currentReservation,
			BindingResult theBindingResult, Model model) throws Exception {
		
		// send reservation to services to save it in database
		reservationService.saveReservation(currentReservation);
        
		return "redirect:/your-reservations";
	}

	// update new reservation
		@PostMapping("/proceed-reservationupdate")
		public String proceedReservationUpdate(@Valid @ModelAttribute("newRes") CurrentReservation currentReservation,
				BindingResult theBindingResult, Model model) throws Exception {
			
			// send reservation to services to save it in database
			reservationService.updateReservation(currentReservation);
	        
			return "redirect:/your-reservations";
		}
	
	
	// reservations of user
	@GetMapping("/your-reservations")
	public String reservationsList(Model model) {
		
		// list of reservations for logged user
		model.addAttribute("resList", reservationService.getReservationsForLoggedUser());

		return "reservationslist";
	}
	
	// update reservation
	@PostMapping("/reservation-update")
	public String updateReservation(@RequestParam("resId") int resId, Model model) {
	
		// new update reservation sent to services to store it in database
		model.addAttribute("newRes", reservationService.reservationToCurrentReservationById(resId));
		
		return "reservationupdate";
	}
	

	// delete reservation
	@PostMapping("/reservation-delete")
	  public String deleteReservation(@RequestParam("resId") int resId, @RequestParam("room") String room, @RequestParam("arrdate") String arrdate, @RequestParam("enddate") String enddate) throws ParseException {
	////public String deleteReservation(@RequestParam("resId") int resId, @RequestParam("room") String room) { 
		// delete reservation sent to services to delete from database 
		Bookedroom bookedroom = new Bookedroom();
		
		reservationService.deleteReservation(resId);
		//String room = "Single Standard";
		bookedroom.setRoomType(room);
		System.out.println("room is :" + room);
		Date start1 = new SimpleDateFormat("yyyy-MM-dd").parse(arrdate);
		Date end1 = new SimpleDateFormat("yyyy-MM-dd").parse(enddate);
		LocalDate start2 = start1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	LocalDate end2 = end1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	for (LocalDate date = start2; date.isBefore(end2); date = ((LocalDate) date).plusDays(1)) {
    	    // Do your job here with `date`.
    		bookedroom.setRoomDate(date);
    		bookedroomRepository.delete(bookedroom); 
    	}
		
		
		return "redirect:/your-reservations";
	}
	
	

}
