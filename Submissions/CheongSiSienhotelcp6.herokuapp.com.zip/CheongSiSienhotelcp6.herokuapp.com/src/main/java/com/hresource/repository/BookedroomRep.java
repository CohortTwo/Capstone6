package com.hresource.repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hresource.model.Bookedroom;
import com.hresource.model.Reservation;
import com.hresource.repository.RoomId;


import org.springframework.data.repository.CrudRepository;

@Repository
public interface BookedroomRep extends JpaRepository<Bookedroom, RoomId> {
	boolean existsByRoomTypeAndRoomDate(String room, LocalDate date);
	}
	
