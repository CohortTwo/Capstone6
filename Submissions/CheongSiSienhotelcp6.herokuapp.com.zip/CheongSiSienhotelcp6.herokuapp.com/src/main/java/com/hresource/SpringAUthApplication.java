package com.hresource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAUthApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringAUthApplication.class, args);
	}

}

