package com.hresource.temp;

import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

public class CurrentReservation {
	
	// temp class to filter data and get it from controller to database using services
	//  current reservation fields and annotate to get the required data
	
	@NotNull(message = "is required")
	private int id;

	@NotNull(message = "is required")
	@Min(value = 1, message = "The value must be positive")
	private String room;

	@NotNull(message = "is required")
	private int price;

	@NotNull(message = "is required")
	@Min(value = 1, message = "The value must be positive")
	private int rooms;

	@NotNull(message = "is required")
	@Min(value = 1, message = "The value must be positive")
	private int persons;

	@NotNull(message = "is required")
	@Max(value = 4, message = "The value must not be more than 4")
	private int children;

	@NotNull(message = "is required")
	private int openBuffet;

	@NotNull(message = "is required")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date arrivalDate;
	
	@NotNull(message = "is required")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date endDate;

	@NotNull(message = "is required")
	private int usertId;

	// current reservation super and fields constructors

	public CurrentReservation() {
	}

	public CurrentReservation(@NotNull(message = "is required") @Size(min = 1, message = "is required") int id,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int stayPeriod,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") String room,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int price,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int rooms,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int persons,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int children,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int openBuffet,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") Date arrivalDate,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") Date endDate,
			@NotNull(message = "is required") @Size(min = 1, message = "is required") int usertId) {
		super();
		this.id = id;
		this.room = room;
		this.price = price;
		this.rooms = rooms;
		this.persons = persons;
		this.children = children;
		this.openBuffet = openBuffet;
		this.arrivalDate = arrivalDate;
		this.endDate = endDate;
		this.usertId = usertId;
	}
	
	// current reservation getters and setters fields

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getRooms() {
		return rooms;
	}

	public void setRooms(int rooms) {
		this.rooms = rooms;
	}

	public int getPersons() {
		return persons;
	}

	public void setPersons(int persons) {
		this.persons = persons;
	}

	public int getChildren() {
		return children;
	}

	public void setChildren(int children) {
		this.children = children;
	}

	public int getOpenBuffet() {
		return openBuffet;
	}

	public void setOpenBuffet(int openBuffet) {
		this.openBuffet = openBuffet;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	
	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	

	public int getUsertId() {
		return usertId;
	}

	public void setUsertId(int usertId) {
		this.usertId = usertId;
	}

	@Override
	public String toString() {
		return "CurrentReservation [id=" + id + ", room=" + room + ", price=" + price + ", rooms=" + rooms
				+ ", persons=" + persons + ", children=" + children + ", openBuffet=" + openBuffet + ", arrivalDate="
				+ arrivalDate + ", endDate=" + endDate + ", usertId=" + usertId + "]";
	}

	// override to string method to contain all fields

	
}
