package com.hresource.service;

import java.time.LocalDate;
import java.util.Collection;

import com.hresource.model.Reservation;
import com.hresource.temp.CurrentReservation;

//Service Pattern for Reservation
public interface ReservationService {
	
	public Reservation getReservationForLoggedUserById(int resId);

	public Collection<Reservation> getReservationsForLoggedUser();
	
	public void saveReservation(CurrentReservation currentReservation) throws Exception;
	
	public void updateReservation(CurrentReservation currentReservation) throws Exception;
	
	public void deleteReservation(int resId);

	public CurrentReservation reservationToCurrentReservationById(int resId);

}
