package com.hresource.exception;


public class ReservationBookedException extends RuntimeException {
	
}
	