package com.hresource.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.hresource.model.User;
import com.hresource.repository.UserRep;

public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserRep userRep;
	
	@Override
	public UserDetails loadUserByUsername(String username) 
			throws UsernameNotFoundException {
		User user = userRep.getUserByUsername(username);
		
		if (user == null) {
			throw new UsernameNotFoundException("Could not find user");
		}
			return new MyUserDetails(user);
	}

}
