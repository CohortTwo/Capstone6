package com.hresource.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.hresource.repository.RoomId;

@Entity
@Table(name = "bookedroom")
@IdClass(RoomId.class)
public class Bookedroom implements Serializable {

    @Id
    private String roomType;
    @Id
    private LocalDate roomDate;

    public Bookedroom() {
    }

    public Bookedroom(String roomType, LocalDate roomDate) {
		super();
		this.roomType = roomType;
		this.roomDate = roomDate;
	}



	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public LocalDate getRoomDate() {
		return roomDate;
	}

	public void setRoomDate(LocalDate roomDate) {
		this.roomDate = roomDate;
	}
    
    






}

