package com.hresource.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hresource.model.Role;

public interface RoleRep extends JpaRepository<Role, Integer>{
	Role findByName(String roleName);
}
