package com.hresource.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;
import com.hresource.model.Role;
import com.hresource.model.User;
import com.hresource.repository.RoleRep;
import com.hresource.repository.UserRep;
import com.lowagie.text.DocumentException;

@Controller
public class UserController {

	@Autowired
	private UserRep repo;
	
	@Autowired
	private RoleRep rolerepo;
	
	@RequestMapping("/users")
	public String ShowUsersList(Model model) {
		java.util.List<User> listUsers = repo.findAll();
		model.addAttribute("listUsers", listUsers);
		return "users";
	}
	
	
	
	@GetMapping("/users/new")
	public String ShowUserform(Model model) {
		List<Role> roles = rolerepo.findAll();
		model.addAttribute("roles", roles);
		model.addAttribute("Users", new User());
		return "user_form";
	}
	
	@PostMapping("/users/save")
	public String saveUser(User user) {
		repo.save(user);
		return "redirect:/users";
	}
	
	@GetMapping("/users/details/{id}")
	public String ShowEditForm(@PathVariable("id") Long id, Model model) {
		User user =   repo.findById(id).get();
		model.addAttribute("Users", user);
		
		List<Role> roles = rolerepo.findAll();
		model.addAttribute("roles", roles);
		
		return "user_form";
	}
	
	@GetMapping("/users/delete/{id}")
	public String deleteUser(@PathVariable("id") Long id, Model model) {
		repo.deleteById(id);;
		return "redirect:/users";
		
	}
}
