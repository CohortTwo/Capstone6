package com.hresource.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hresource.exception.ReservationBookedException;
import com.hresource.model.Bookedroom;
import com.hresource.model.Reservation;
import com.hresource.repository.ReservationRep;
import com.hresource.repository.RoomId;
import com.hresource.repository.BookedroomRep;
import com.hresource.temp.CurrentReservation;

@Service
public class ReservationServiceImpl implements ReservationService {
	
	// service pattern to manage transactionals  
	//	and handle services for reservation between server and client
	
	private UserService userService;

	private ReservationRep reservationRepository;
	
	private BookedroomRep bookedroomRepository;
	
	@Autowired
	public ReservationServiceImpl(UserService userService, ReservationRep reservationRepository, BookedroomRep bookedroomRepository) {
		this.userService = userService;
		this.reservationRepository = reservationRepository;
		this.bookedroomRepository = bookedroomRepository;
	}

	
	
	
	// get reservation for logged user
	@Override
	@Transactional
	public Reservation getReservationForLoggedUserById(int resId) {
		
		return reservationRepository.findById(resId);
	}

	// get all reservations for logger user 
	@Override
	@Transactional
	public Collection<Reservation> getReservationsForLoggedUser() {
		return reservationRepository.findAllByUserId((userService.getLoggedUserId()));
	}

	// transfer data between temp reservation and Reservation class after check it to save it 
	@Override
	@Transactional
	public void saveReservation(CurrentReservation currentReservation) {
		Reservation reservation = new Reservation();
		Bookedroom bookedroom = new Bookedroom();

		// get required id user using user services
		reservation.setUserId(userService.getLoggedUserId());
		reservation.setArrivalDate(currentReservation.getArrivalDate());
		reservation.setOpenBuffet(currentReservation.getOpenBuffet());
		reservation.setEndDate(currentReservation.getEndDate());
		reservation.setChildren(currentReservation.getChildren());
		reservation.setPersons(currentReservation.getPersons());
		reservation.setPrice(currentReservation.getPrice());
		reservation.setRoom(currentReservation.getRoom());
		reservation.setId(currentReservation.getId());
		bookedroom.setRoomType(currentReservation.getRoom());
		LocalDate start = currentReservation.getArrivalDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	LocalDate end = currentReservation.getEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    	
    	boolean isExists;
		for (LocalDate date = start; date.isBefore(end); date = ((LocalDate) date).plusDays(1)) {
			System.out.println("date is:" + date);		
		isExists = bookedroomRepository.existsByRoomTypeAndRoomDate(currentReservation.getRoom(), date);
			if (isExists) {
				throw new ReservationBookedException();
			}
       	}
    	
			
		
			reservationRepository.save(reservation);
        	
        	LocalDate start1 = currentReservation.getArrivalDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        	LocalDate end1 = currentReservation.getEndDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        	for (LocalDate date = start1; date.isBefore(end1); date = ((LocalDate) date).plusDays(1)) {
        	    // Do your job here with `date`.
        		bookedroom.setRoomDate(date);
        		bookedroomRepository.save(bookedroom); 
        	    System.out.println(date);
        	}
		
	}
	
	
	@Override
	@Transactional
	public void updateReservation(CurrentReservation currentReservation) {
		Reservation reservation = new Reservation();

		// get required id user using user services
		reservation.setUserId(userService.getLoggedUserId());
		reservation.setArrivalDate(currentReservation.getArrivalDate());
		reservation.setOpenBuffet(currentReservation.getOpenBuffet());
		reservation.setEndDate(currentReservation.getEndDate());
		reservation.setChildren(currentReservation.getChildren());
		reservation.setPersons(currentReservation.getPersons());
		reservation.setPrice(currentReservation.getPrice());
		reservation.setRoom(currentReservation.getRoom());
		reservation.setId(currentReservation.getId());
		reservationRepository.save(reservation);
	}
	
	
	// transfer data between Reservation and temp Reservation class to update request  
	@Override
	public CurrentReservation reservationToCurrentReservationById(int resId) {
		Reservation reservation = getReservationForLoggedUserById(resId);
		CurrentReservation currentReservation = new CurrentReservation();
		currentReservation.setEndDate(reservation.getEndDate());
		currentReservation.setArrivalDate(reservation.getArrivalDate());
		currentReservation.setOpenBuffet(reservation.getOpenBuffet());
		currentReservation.setChildren(reservation.getChildren());
		currentReservation.setPersons(reservation.getPersons());
		currentReservation.setUsertId(reservation.getUserId());
		currentReservation.setPrice(reservation.getPrice());
		currentReservation.setRoom(reservation.getRoom());
		currentReservation.setId(reservation.getId());
		
		return currentReservation;
	}
	
	// delete reservation 
	@Override
	@Transactional
	public void deleteReservation(int resId) {
		
		reservationRepository.deleteById(resId);
	}
}
