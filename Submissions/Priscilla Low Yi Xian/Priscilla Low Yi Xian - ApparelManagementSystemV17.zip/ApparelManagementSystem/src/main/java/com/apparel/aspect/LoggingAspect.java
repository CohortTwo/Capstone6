package com.apparel.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.apparel.ApparelManagementSystemApplication;


@Component
@Aspect
public class LoggingAspect {

	Logger logger = LoggerFactory.getLogger(ApparelManagementSystemApplication.class);

	@Before("execution(public String goHome())")
	public void LoggingHomeBeforeAdvice() {
		System.out.println("Advice run. The goHome method is called");
		 logger.info("The Advice Get method has been called for goHome.");
	}

	@After("execution(public String goHome())")
	public void LoggingHomeAfterAdvice() {
		 logger.info("The Advice for goHome method has been called.");

	}
	
	@Before("execution(public String goLogin())")
	public void LoggingLoginBeforeAdvice() {
		System.out.println("Advice run. The goLogin method is called");
		 logger.info("The Advice Get method has been called for goLogin.");
	}

	@After("execution(public String goLogin())")
	public void LoggingLoginAfterAdvice() {
		 logger.info("The Advice for goLogin method has been called.");

	}
	
	@Before("execution(public String goErrorLogin())")
	public void LoggingErrorLoginBeforeAdvice() {
		System.out.println("Advice run. The goErrorLogin method is called");
		 logger.info("The Advice Get method has been called for goErrorLogin.");
	}

	@After("execution(public String goErrorLogin())")
	public void LoggingErrorLoginAfterAdvice() {
		 logger.info("The Advice for goErrorLogin method has been called.");

	}

}
