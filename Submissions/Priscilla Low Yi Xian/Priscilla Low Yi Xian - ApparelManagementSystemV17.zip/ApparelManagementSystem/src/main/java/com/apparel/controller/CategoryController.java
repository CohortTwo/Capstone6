package com.apparel.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.apparel.model.Category;
import com.apparel.model.CategoryPDFExporter;
import com.apparel.repository.CategoryRepository;
import com.lowagie.text.DocumentException;

@Controller
public class CategoryController {
	
	@Autowired
	private CategoryRepository catrepo;
	
	@GetMapping("/categories")
	public String listCategories(Model model) {
		List<Category> listcategories = catrepo.findAll();
		model.addAttribute("listcategories",listcategories);
		return "categories";
	}
	
	@GetMapping("/categories/new")
	public String showNewCategoryForm(Model model) {
		model.addAttribute("category", new Category());
		return "category_form";
	}
	
	@PostMapping("/categories/save")
	public String saveCategoryForm(Category category) {
		catrepo.save(category);
		return "redirect:/categories";
	}
	
	@GetMapping("/categories/export/pdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=categories_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<Category> listCategories = catrepo.findAll();
         
       CategoryPDFExporter exporter = new CategoryPDFExporter(listCategories);
       exporter.export(response);
    }
	
	@GetMapping("/categories/export/csv")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=categories_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
         
        List<Category> listCategories = catrepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"Category ID", "Name"};
        String[] nameMapping = {"id", "name"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (Category categories : listCategories) {
            csvWriter.write(categories, nameMapping);
        }
         
        csvWriter.close();
         
    }
}
