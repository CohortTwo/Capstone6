package com.apparel;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.apparel.model.SystemUserDetailsServiceImpl;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	
	@Bean
	public UserDetailsService userDetailsService() {
		return new SystemUserDetailsServiceImpl();
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
		authProvider.setUserDetailsService(userDetailsService()); //use the method above
		authProvider.setPasswordEncoder(passwordEncoder()); //use the method above
		
		return authProvider;
	}
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
        auth.authenticationProvider(authenticationProvider()); //use the method above
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		//List the url to static resources/folders so that it can be loaded at login page
		//when user is not yet authenticated.
	    String[] staticResources  =  {
	            "/images/**",
	        };
		
		// Method below uses default login page by Spring.
//		http.authorizeRequests()
//		.anyRequest().authenticated()
//		.and()
//		.formLogin().permitAll()
//		.and()
//		.logout().permitAll();
	    
		//Method below uses configured login page without image loaded.
//		http.authorizeRequests()
//		.anyRequest().authenticated()
//		.and()
//		.formLogin()
//		.loginPage("/login")
//		.defaultSuccessUrl("/")
//		.permitAll()
//		.failureUrl("/login-error")
//		.and()
//		.logout().permitAll();
		
		//Method below uses configured login page with image loaded.
//		http.authorizeRequests()
//		.antMatchers(staticResources).permitAll()
//		.anyRequest().authenticated()
//		.and()
//		.formLogin()
//		.loginPage("/login")
//		.defaultSuccessUrl("/") //This means the page that will appear after you login.
//		.permitAll()
//		.failureUrl("/login-error")
//		.and()
//		.logout().permitAll();
		
	    //Method below uses configured login page with image loaded and has OAuth.
		http.authorizeRequests()
		.antMatchers(staticResources).permitAll()
	 	.anyRequest().authenticated()
		.and()
		.formLogin()
		.loginPage("/login")
		.defaultSuccessUrl("/")
		.permitAll()
		.failureUrl("/login-error")
		.and()
		.oauth2Login()
		.loginPage("/login")
		.permitAll()
		.failureUrl("/login-error")
		.and()
		.logout()
		.invalidateHttpSession(true)
		.clearAuthentication(true)
		.logoutSuccessUrl("/login?logout")
		.permitAll();

		
	}


	
}
