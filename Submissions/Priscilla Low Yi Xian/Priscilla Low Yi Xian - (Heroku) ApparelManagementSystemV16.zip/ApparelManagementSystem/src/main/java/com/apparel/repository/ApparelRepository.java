package com.apparel.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.apparel.model.Apparel;


public interface ApparelRepository extends JpaRepository<Apparel, Integer> {

	@Query("SELECT a FROM Apparel a WHERE "
			+ " LOWER(CONCAT(a.id, a.category.name, a.price, a.qty, a.type))" 
			+  " LIKE LOWER(CONCAT('%',?1,'%'))" )
	public Page<Apparel> findAll(String keyword,Pageable pageable);
	//%?1% means it will automatically look at the input of the text box, 
	//assuming there is only one text box. If got more than 1, then can put
	//%?2% or %?3% etc depending on the order you give. This is called an 
	//unnamed query.
}
