package com.apparel;

import java.security.Principal;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AppController {
	@GetMapping("/")
	public String goHome() {
		return "index";
	}
	
	@GetMapping("/login")
	public String goLogin() {
		return "login";
	}
	
	@GetMapping("/login-error")
	public String goErrorLogin() {
		return "login-error";
	}
	
	@GetMapping("/testaop")
	public String TestAop(Principal principal) {
		return "Welcomeaop";
	}
}
