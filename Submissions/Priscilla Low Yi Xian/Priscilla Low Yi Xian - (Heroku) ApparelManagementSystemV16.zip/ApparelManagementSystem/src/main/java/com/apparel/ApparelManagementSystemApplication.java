package com.apparel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApparelManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApparelManagementSystemApplication.class, args);
	}

}
