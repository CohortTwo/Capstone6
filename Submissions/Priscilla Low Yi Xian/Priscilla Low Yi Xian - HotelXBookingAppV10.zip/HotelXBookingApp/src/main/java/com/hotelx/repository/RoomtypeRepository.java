package com.hotelx.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hotelx.model.Roomtype;


@Repository
public interface RoomtypeRepository extends JpaRepository<Roomtype, Integer> {

	@Query("SELECT rt FROM Roomtype rt WHERE rt.name = :name")
	public Roomtype getRoomtypeByInput(@Param("name") String name);
	
}
