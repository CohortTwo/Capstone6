package com.hotelx.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hotelx.model.Booking;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {
	
	@Query(value = "select startdate from Booking", nativeQuery = true)
    Date[] showStartDate();
	
	@Query(value = "select enddate from Booking", nativeQuery = true)
    Date[] showEndDate();
	
	
}
