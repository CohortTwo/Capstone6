package com.hotelx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelXBookingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelXBookingAppApplication.class, args);
	}

}
