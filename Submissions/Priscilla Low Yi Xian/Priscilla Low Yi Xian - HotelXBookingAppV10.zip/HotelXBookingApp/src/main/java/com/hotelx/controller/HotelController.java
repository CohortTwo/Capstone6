package com.hotelx.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.hotelx.model.Hotel;
import com.hotelx.repository.HotelRepository;

@Controller
public class HotelController {

	@Autowired
	private HotelRepository hotelrepo;

	
	 @GetMapping("/hotelrooms") 
	 public String listHotel(Model model) {
	 List<Hotel> listHotel = hotelrepo.findAll();
	 model.addAttribute("listHotel",listHotel); 
	 return "hotelrooms"; 
	 }
	 

}
