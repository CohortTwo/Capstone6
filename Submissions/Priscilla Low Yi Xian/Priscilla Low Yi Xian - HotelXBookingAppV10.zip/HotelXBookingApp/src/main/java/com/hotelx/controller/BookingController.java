package com.hotelx.controller;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hotelx.model.Booking;
import com.hotelx.model.Hotel;
import com.hotelx.model.Roomtype;
import com.hotelx.repository.BookingRepository;
import com.hotelx.repository.HotelRepository;
import com.hotelx.repository.RoomtypeRepository;


@Controller
public class BookingController {
	
	@Autowired
	private BookingRepository bookingrepo;
	
	@Autowired
	private RoomtypeRepository roomtyperepo;
	
	@Autowired
	private HotelRepository hotelrepo;
	
	
//	@GetMapping("/hotelbookings/new")
//	public String showNewBookingForm(Model model) {
//		List<Roomtype> listroomtypes = roomtyperepo.findAll();
//		List<Hotel> listroomno= hotelrepo.findAll();
////		List<Hotel> listroomno= hotelrepo.findAvailableRooms(true);
//		model.addAttribute("booking", new Booking());
//		model.addAttribute("listroomtypes", listroomtypes);
//		model.addAttribute("listroomno", listroomno);
//		
////		Booking sd = new Booking();
////		Date[] listdates = bookingrepo.showDates();
////		String[] finalDates= new String[listdates.length];
////		SimpleDateFormat b = new SimpleDateFormat("d-M-yyyy");
////			for(int i=0;i<listdates.length;i++) {
////				finalDates[i]=b.format(listdates[i]);
////			}
////		model.addAttribute("finalDates", finalDates);
////		model.addAttribute("bd", bd);
//		
//		
//		Booking sd = new Booking();
//		Date[] liststartdates = bookingrepo.showStartDate();
//		String[] finalstartdates= new String[liststartdates.length];
//		SimpleDateFormat sdf = new SimpleDateFormat("d-M-yyyy");
//			for(int i=0;i<liststartdates.length;i++) {
//				finalstartdates[i]=sdf.format(liststartdates[i]);
//			}
//		model.addAttribute("finalstartdates", finalstartdates);
//		model.addAttribute("sd", sd);
//		
//		Booking ed = new Booking();
//		Date[] listenddates = bookingrepo.showEndDate();
//		String[] finalenddates= new String[listenddates.length];
//		SimpleDateFormat edf = new SimpleDateFormat("d-M-yyyy");
//			for(int i=0;i<listenddates.length;i++) {
//				finalenddates[i]=edf.format(listenddates[i]);
//			}
//		model.addAttribute("finalenddates", finalenddates);
//		model.addAttribute("ed", ed);
//		
//		return "booking_form";
//
//	}
	
	@GetMapping("/hotelbookings/new/{roomtype}/{id}")
	public String showNewBookingForm(@PathVariable("id") Integer id, @PathVariable("roomtype") String roomtype, Model model, HttpSession session) {
		Hotel listroomno= hotelrepo.findById(id).get();
		model.addAttribute("listroomno", listroomno);
		
//		List<Roomtype> listroomtypes = roomtyperepo.findAll();
		Roomtype listroomtypes = roomtyperepo.getRoomtypeByInput(roomtype);
		model.addAttribute("booking", new Booking());
		model.addAttribute("listroomtypes", listroomtypes);
		
		Booking sd = new Booking();
		Date[] liststartdates = bookingrepo.showStartDate();
		String[] finalstartdates= new String[liststartdates.length];
		SimpleDateFormat sdf = new SimpleDateFormat("d-M-yyyy");
			for(int i=0;i<liststartdates.length;i++) {
				finalstartdates[i]=sdf.format(liststartdates[i]);
			}
		model.addAttribute("finalstartdates", finalstartdates);
		model.addAttribute("sd", sd);
		
		Booking ed = new Booking();
		Date[] listenddates = bookingrepo.showEndDate();
		String[] finalenddates= new String[listenddates.length];
		SimpleDateFormat edf = new SimpleDateFormat("d-M-yyyy");
			for(int i=0;i<listenddates.length;i++) {
				finalenddates[i]=edf.format(listenddates[i]);
			}
		model.addAttribute("finalenddates", finalenddates);
		model.addAttribute("ed", ed);
		
		Object date=new Date();
		session.setAttribute("today", date);
		
		return "booking_form";
	}
	
	@PostMapping("/hotelbookings/save")
	public String saveBooking(Booking booking, BindingResult bindingResult, HttpServletRequest request, HttpSession session) {
		
		if (bindingResult.hasErrors()) {
			return "booking_form";
		}
		
		String cname = (String) session.getAttribute("name");
		String cemail = (String) session.getAttribute("email");
		
		Roomtype croomtype = (Roomtype) session.getAttribute("roomtype");
		
		Hotel croomno = (Hotel) session.getAttribute("roomno");
		
		String cstartdate = (String) session.getAttribute("startdate");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-M-yyyy");
		LocalDate localstartDate = LocalDate.parse(cstartdate, formatter);
		
		String cenddate = (String) session.getAttribute("enddate");
		LocalDate localendDate = LocalDate.parse(cenddate, formatter);
		 
		booking.setName(cname);
		booking.setEmail(cemail);
		booking.setRoomtype(croomtype);
		booking.setRoomno(croomno);
		booking.setStartdate(localstartDate);
		booking.setEnddate(localendDate);
		
		bookingrepo.save(booking);
		
		return "booking-success";
	}
	
	 
	
//	@PostMapping("/hotelbookings/save")
//	public String saveBooking(Booking booking, HttpServletRequest request) {
//		bookingrepo.save(booking);
//		return "booking-success";
//	}
	
	@GetMapping("/hotelbookings/confirmation")
	public String confirmBooking(@ModelAttribute Booking booking, @RequestParam("name") String name, @RequestParam("email") String email, @RequestParam("roomno") Hotel roomno, @RequestParam("roomtype") Roomtype roomtype, @RequestParam("startdate") String startdate, @RequestParam("enddate") String enddate, HttpSession session) {
		
		session.setAttribute("name", name);
		session.setAttribute("email", email);
		session.setAttribute("roomtype", roomtype);
		session.setAttribute("roomno", roomno);
		session.setAttribute("startdate", startdate);
		session.setAttribute("enddate", enddate);
		
		
		return "booking-confirmation";
	}
	
	@GetMapping("/hotelbookings/blockdates")
	public String showBlockDates(Model model) {
		List<Booking> listbookings = bookingrepo.findAll();
		
		model.addAttribute("listbookings", listbookings);
		
		return "blockdates";

	}
}
