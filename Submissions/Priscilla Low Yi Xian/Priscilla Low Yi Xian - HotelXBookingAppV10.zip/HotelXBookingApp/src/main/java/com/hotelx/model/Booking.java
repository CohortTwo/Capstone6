package com.hotelx.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_id")
	private Integer id;
	
	@Column(name = "customer_name")
	private String name;
	
	@Column(name = "customer_email")
	private String email;
	
	
	@DateTimeFormat(pattern="d-M-yyyy")
	private LocalDate startdate;
	
	
	@DateTimeFormat(pattern="d-M-yyyy")
	private LocalDate enddate;
	
	@ManyToOne
	@JoinColumn(name= "roomtype_id")
	private Roomtype roomtype;
	
	@OneToOne
	@JoinColumn(name= "room_no")
	private Hotel roomno;

	public long totalNights() {
		if (startdate ==null || enddate == null) {
			return 0;
		} return ChronoUnit.DAYS.between(startdate, enddate);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public LocalDate getStartdate() {
		return startdate;
	}

	public void setStartdate(LocalDate startdate) {
		this.startdate = startdate;
	}

	public LocalDate getEnddate() {
		return enddate;
	}

	public void setEnddate(LocalDate enddate) {
		this.enddate = enddate;
	}
	
	public Roomtype getRoomtype() {
		return roomtype;
	}

	public void setRoomtype(Roomtype roomtype) {
		this.roomtype = roomtype;
	}


	public Hotel getRoomno() {
		return roomno;
	}

	public void setRoomno(Hotel roomno) {
		this.roomno = roomno;
	}

	

	public Booking(Integer id, String name, String email, LocalDate startdate, LocalDate enddate, Roomtype roomtype, Hotel roomno) {
	this.id = id;
	this.name = name;
	this.email = email;
	this.startdate = startdate;
	this.enddate = enddate;
	this.roomtype = roomtype;
	this.roomno = roomno;
	}
	
	
	
	public Booking() {
	}
	


	@Override
	public String toString() {
		return "Booking [id=" + id + ", name=" + name + ", email=" + email + ", startdate=" + startdate + ", enddate="
				+ enddate + ", roomtype=" + roomtype + ", roomno=" + roomno + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((enddate == null) ? 0 : enddate.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((roomno == null) ? 0 : roomno.hashCode());
		result = prime * result + ((roomtype == null) ? 0 : roomtype.hashCode());
		result = prime * result + ((startdate == null) ? 0 : startdate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (enddate == null) {
			if (other.enddate != null)
				return false;
		} else if (!enddate.equals(other.enddate))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (roomno == null) {
			if (other.roomno != null)
				return false;
		} else if (!roomno.equals(other.roomno))
			return false;
		if (roomtype == null) {
			if (other.roomtype != null)
				return false;
		} else if (!roomtype.equals(other.roomtype))
			return false;
		if (startdate == null) {
			if (other.startdate != null)
				return false;
		} else if (!startdate.equals(other.startdate))
			return false;
		return true;
	}

	
}
