package com.ntuc.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.util.Streamable;

import com.ntuc.model.Booking;


public interface BookingRepository extends JpaRepository<Booking, Long>{
	
	/* Booking findById(Long bookid); */
  //  @Query("SELECT b FROM Booking b WHERE b.booking_id = :booking_id")
	//public Booking findBookingById(@Param("booking_id") Long bookid);
	
	// Set<Booking> findAllByUserId(@Param("booking_id")Long userid); 
	
//	@Query("SELECT b FROM Booking b WHERE "
//			+ " CONCAT(b.booking_id, b.hotelname, b.room, b.price, b.startdate, b.enddate, b.duration, b.person, b.children, b.numofrooms)"
//			+ " LIKE %?1%" )
//	public Page<Booking> findAll(String keyword, Pageable pageable);

	
	@Query(value = "SELECT b FROM Booking b ORDER BY booking_id")
	public Page<Booking> findAll(String keyword, Pageable pageable);
	
	public void deleteById(Integer id);

	public Streamable<Order> findById(Integer id);
	 
	

}
