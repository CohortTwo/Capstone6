package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ntuc.model.Hotel;

public interface HotelRepository extends JpaRepository<Hotel, Integer>{

//	@Query("SELECT h FROM Hotel h WHERE h.name = :name")
//	public Hotel getHotelNameByName(@Param("name") String name);
}
