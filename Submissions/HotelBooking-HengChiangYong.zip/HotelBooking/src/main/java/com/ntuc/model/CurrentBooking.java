package com.ntuc.model;

import java.util.Date;

import javax.persistence.Column;

public class CurrentBooking {

	
	@Column(nullable=false)
	private Long id;
	
	@Column(nullable=false)
	private String room;
	
	@Column(nullable=false)
	private Float price;
	
	@Column(nullable=false)
	private Integer stayPeriod;
	
	@Column(nullable=false)
	private Integer numofrooms;
	
	@Column(nullable=false)
	private Integer numofpersons;
	
	@Column(nullable=false)
	private Integer children;
	
	@Column(nullable=false)
	private Date arrival;
	
	@Column(nullable=false)
	private Date departure;
	
	@Column(nullable=false)
	private Integer userid;

	public CurrentBooking() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrentBooking(Long id, String room, Float price, Integer stayPeriod, Integer numofrooms,
			Integer numofpersons, Integer children, Date arrival, Date departure, Integer userid) {
		super();
		this.id = id;
		this.room = room;
		this.price = price;
		this.stayPeriod = stayPeriod;
		this.numofrooms = numofrooms;
		this.numofpersons = numofpersons;
		this.children = children;
		this.arrival = arrival;
		this.departure = departure;
		this.userid = userid;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getStayPeriod() {
		return stayPeriod;
	}

	public void setStayPeriod(Integer stayPeriod) {
		this.stayPeriod = stayPeriod;
	}

	public Integer getNumofrooms() {
		return numofrooms;
	}

	public void setNumofrooms(Integer numofrooms) {
		this.numofrooms = numofrooms;
	}

	public Integer getNumofpersons() {
		return numofpersons;
	}

	public void setNumofpersons(Integer numofpersons) {
		this.numofpersons = numofpersons;
	}

	public Integer getChildren() {
		return children;
	}

	public void setChildren(Integer children) {
		this.children = children;
	}

	public Date getArrival() {
		return arrival;
	}

	public void setArrival(Date arrival) {
		this.arrival = arrival;
	}

	public Date getDeparture() {
		return departure;
	}

	public void setDeparture(Date departure) {
		this.departure = departure;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	@Override
	public String toString() {
		return "CurrentBooking [id=" + id + ", room=" + room + ", price=" + price + ", stayPeriod=" + stayPeriod
				+ ", numofrooms=" + numofrooms + ", numofpersons=" + numofpersons + ", children=" + children
				+ ", arrival=" + arrival + ", departure=" + departure + ", userid=" + userid + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arrival == null) ? 0 : arrival.hashCode());
		result = prime * result + ((children == null) ? 0 : children.hashCode());
		result = prime * result + ((departure == null) ? 0 : departure.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((numofpersons == null) ? 0 : numofpersons.hashCode());
		result = prime * result + ((numofrooms == null) ? 0 : numofrooms.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((room == null) ? 0 : room.hashCode());
		result = prime * result + ((stayPeriod == null) ? 0 : stayPeriod.hashCode());
		result = prime * result + ((userid == null) ? 0 : userid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CurrentBooking other = (CurrentBooking) obj;
		if (arrival == null) {
			if (other.arrival != null)
				return false;
		} else if (!arrival.equals(other.arrival))
			return false;
		if (children == null) {
			if (other.children != null)
				return false;
		} else if (!children.equals(other.children))
			return false;
		if (departure == null) {
			if (other.departure != null)
				return false;
		} else if (!departure.equals(other.departure))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (numofpersons == null) {
			if (other.numofpersons != null)
				return false;
		} else if (!numofpersons.equals(other.numofpersons))
			return false;
		if (numofrooms == null) {
			if (other.numofrooms != null)
				return false;
		} else if (!numofrooms.equals(other.numofrooms))
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (room == null) {
			if (other.room != null)
				return false;
		} else if (!room.equals(other.room))
			return false;
		if (stayPeriod == null) {
			if (other.stayPeriod != null)
				return false;
		} else if (!stayPeriod.equals(other.stayPeriod))
			return false;
		if (userid == null) {
			if (other.userid != null)
				return false;
		} else if (!userid.equals(other.userid))
			return false;
		return true;
	}
	

	
	
	
}
