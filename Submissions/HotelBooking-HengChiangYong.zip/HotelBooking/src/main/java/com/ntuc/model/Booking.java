package com.ntuc.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="booking")
public class Booking {
	
	@Id
	@Column(name="booking_id", columnDefinition="serial")
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	
//	@Column(name="booking_userid")
//	private int userid;
	
	@Column(name="hotel_name")
	private String hotelname;
	
	@Column(name="booking_room")
	private String room;
	
	
	@Column(name="booking_price")
	private Float price;
	
	@Column(nullable=false)			//arrival date
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date startdate;
	
	@Column(nullable=false)			//departure date
	@DateTimeFormat(pattern = "dd-MM-yyyy")
	private Date enddate;
	
	private Integer duration;		//number of days to stay
	
	@Column(name="num_of_persons")
	private Integer persons;			//number of people staying
	
	@Column(name="num_of_children")
	private Integer children;
	
	@Column(name="num_of_rooms")
	private Integer numofrooms;
	
	@OneToMany(fetch=FetchType.LAZY, cascade=CascadeType.ALL)
	@JoinColumn(name="booking_hotelid")
	private Set<Hotel> hotels = new HashSet();

	public Booking() {
		super();
	}

	public Booking(Long id, int userid, String hotelname, String room, Float price, Date startdate, Date enddate,
			Integer duration, Integer persons, Integer children, Integer numofrooms, Set<Hotel> hotels) {
		super();
		this.id = id;
	//	this.userid = userid;
		this.hotelname = hotelname;
		this.room = room;
		this.price = price;
		this.startdate = startdate;
		this.enddate = enddate;
		this.duration = duration;
		this.persons = persons;
		this.children = children;
		this.numofrooms = numofrooms;
		this.hotels = hotels;
	}

	

	@Override
	public String toString() {
		return "Booking [id=" + id + ", userid=" + ", hotelname=" + hotelname + ", room=" + room + ", price="
				+ price + ", startdate=" + startdate + ", enddate=" + enddate + ", duration=" + duration + ", persons="
				+ persons + ", children=" + children + ", numofrooms=" + numofrooms + ", hotels=" + hotels + "]";
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

//	public int getUserid() {
//		return userid;
//	}

//	public void setUserid(int userid) {
//		this.userid = userid;
//	}

	public String getRoom() {
		return room;
	}

	public void setRoom(String room) {
		this.room = room;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public Integer getPersons() {
		return persons;
	}

	public void setPersons(Integer persons) {
		this.persons = persons;
	}

	public Integer getChildren() {
		return children;
	}

	public void setChildren(Integer children) {
		this.children = children;
	}

	public Integer getNumofrooms() {
		return numofrooms;
	}

	public void setNumofrooms(Integer numofrooms) {
		this.numofrooms = numofrooms;
	}
	
	

	public Set<Hotel> getHotels() {
		return hotels;
	}



	public void setHotels(Set<Hotel> hotels) {
		this.hotels = hotels;
	}



	public String getHotelname() {
		return hotelname;
	}


	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((children == null) ? 0 : children.hashCode());
		result = prime * result + ((duration == null) ? 0 : duration.hashCode());
		result = prime * result + ((enddate == null) ? 0 : enddate.hashCode());
		result = prime * result + ((hotels == null) ? 0 : hotels.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((numofrooms == null) ? 0 : numofrooms.hashCode());
		result = prime * result + ((persons == null) ? 0 : persons.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((room == null) ? 0 : room.hashCode());
		result = prime * result + ((startdate == null) ? 0 : startdate.hashCode());
//		result = prime * result + userid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Booking other = (Booking) obj;
		if (children == null) {
			if (other.children != null)
				return false;
		} else if (!children.equals(other.children))
			return false;
		if (duration == null) {
			if (other.duration != null)
				return false;
		} else if (!duration.equals(other.duration))
			return false;
		if (enddate == null) {
			if (other.enddate != null)
				return false;
		} else if (!enddate.equals(other.enddate))
			return false;
		if (hotels == null) {
			if (other.hotels != null)
				return false;
		} else if (!hotels.equals(other.hotels))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (numofrooms == null) {
			if (other.numofrooms != null)
				return false;
		} else if (!numofrooms.equals(other.numofrooms))
			return false;
		if (persons == null) {
			if (other.persons != null)
				return false;
		} else if (!persons.equals(other.persons))
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (room == null) {
			if (other.room != null)
				return false;
		} else if (!room.equals(other.room))
			return false;
		if (startdate == null) {
			if (other.startdate != null)
				return false;
		} else if (!startdate.equals(other.startdate))
			return false;
//		if (userid != other.userid)
//			return false;
		return true;
	}
	
}
