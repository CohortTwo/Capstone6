package com.ntuc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.service.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ntuc.model.Booking;
import com.ntuc.model.CurrentBooking;
import com.ntuc.model.Hotel;
import com.ntuc.repository.BookingRepository;
import com.ntuc.repository.HotelRepository;
import com.ntuc.repository.UserRepository;
import com.ntuc.repository.UserRoleRepository;
import com.ntuc.service.HotelBookingService;

@Controller
public class HotelBookingController {

	
	/*
	 * @Autowired private UserRepository userRepo;
	 * 
	 * @Autowired private UserRoleRepository roleRepo;
	 */

	@Autowired
	private BookingRepository bookingRepo;
	
	@Autowired
	private HotelRepository hotelRepo;
	
	@Autowired
	private HotelBookingService service;
	
	//Session
	@GetMapping("/")
	public String homePage() {
		
		return "index";
	}
		
	@GetMapping("/newbooking")
	public String newBooking(@RequestParam("hotel") String hotel, Model model,
			@RequestParam("room") String roomtype,
			@RequestParam("checkin") String checkin,
			@RequestParam("checkout") String checkout,
			@RequestParam("persons") String persons,	
			HttpSession session) {
		session.setAttribute("hotel", hotel);
		session.setAttribute("room", roomtype);
		session.setAttribute("checkin", checkin);
		session.setAttribute("checkout", checkout);
		session.setAttribute("persons", persons);
		
		model.addAttribute("booking", new Booking());
		List<Hotel> listhotels = hotelRepo.findAll();
		model.addAttribute("listHotels",listhotels);
		return "newbooking";
	}
	
	
	@PostMapping("/bookings/confirm")
	public String newBooking(@ModelAttribute("booking") Booking booking, Model model) {
		model.addAttribute("booking", booking);
		return "confirmbooking";
	}
	 
	
	@PostMapping("/bookings/save")
	public String saveBooking(Booking bk, HttpServletRequest request) {
		bookingRepo.save(bk);
		return "redirect:/booking";
	}
	 
	
	@GetMapping("/booking")
	public String ViewBooking(Model model) {
		String keyword = null;
		
		return listByPage(model,1,"id","asc",keyword);
	}
	
	@GetMapping("/booking/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword) {
		Page<Booking> page = service.listAll(currentPage,sortField,sortDir,keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Booking> listbooking = page.getContent();
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listBookings", listbooking);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		System.out.println("total pages = " + totalPages);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		
		return "booking";
		
	}

	/*
	 * @GetMapping("/your-booking") public String bookingList(Model model) {
	 * model.addAttribute("bookinglist", HotelBookingService.getBookingForUser());
	 * 
	 * return "your-booking";
	 * 
	 * 
	 * }
	 */

}
