package com.HotelSession.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HotelSession.Model.HotelTest;
import com.HotelSession.Repository.HotelRepository;


@Service
public class HotelService {
@Autowired
private HotelRepository hrepo;

public void save(HotelTest hoteltest) {
	// TODO Auto-generated method stub
	hrepo.save(hoteltest);
}


}
