package com.HotelSession;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelSessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelSessionApplication.class, args);
	}

}
