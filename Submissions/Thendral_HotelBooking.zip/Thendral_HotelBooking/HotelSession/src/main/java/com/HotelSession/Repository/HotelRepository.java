package com.HotelSession.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HotelSession.Model.HotelTest;


public interface HotelRepository extends JpaRepository<HotelTest,String>{

	

}
