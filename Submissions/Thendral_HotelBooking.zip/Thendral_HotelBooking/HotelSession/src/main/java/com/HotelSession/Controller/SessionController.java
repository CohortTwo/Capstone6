package com.HotelSession.Controller;


import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.HotelSession.Model.HotelTest;

import com.HotelSession.Repository.HotelRepository;
import com.HotelSession.Service.HotelService;



@Controller
public class SessionController {
	@Autowired
	private HotelRepository hrepo;
	
	@Autowired
	private HotelService hservice;
	@GetMapping("/")
	public String NextPage() {
		return "hotel";
	}
	
	@GetMapping("/chooseroom")
	public String OneMorePage(@RequestParam("hotel_name") String hname,HttpSession session) {
		session.setAttribute("hname", hname);
		return "room";
	}
	
	@RequestMapping(value = "/savehotelname", method = RequestMethod.POST)	
	public String saveDepartment(@RequestParam("hotelname") String hname,HttpSession session) {
		System.out.println("inside save");		
		System.out.println(hname);
			
		HotelTest hoteln = new HotelTest();
	   
	    hoteln.setHotelname(hname);
	  
		hrepo.save(hoteln);
		  System.out.println(hoteln.getHotelid());
		  System.out.println(hoteln.getHotelname());
		return "hotel";
	}
}
