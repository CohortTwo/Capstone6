package com.HotelSession.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class HotelTest {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer hotelid;
	private String hotelname;

	public Integer getHotelid() {
		return hotelid;
	}

	public void setHotelid(Integer hotelid) {
		this.hotelid = hotelid;
	}

	public String getHotelname() {
		return hotelname;
	}

	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}

	public HotelTest(Integer hotelid, String hotelname) {
		super();
		this.hotelid = hotelid;
		this.hotelname = hotelname;
	}

	public HotelTest() {
		super();
	}


	
}
