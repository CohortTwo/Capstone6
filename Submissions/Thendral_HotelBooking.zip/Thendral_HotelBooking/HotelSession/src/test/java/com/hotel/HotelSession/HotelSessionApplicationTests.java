package com.hotel.HotelSession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
