package com.hresource.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import java.security.Principal;

import com.hresource.SpringAUthApplication;
import com.hresource.service.MyUserDetails;

@Component
@Aspect
public class LoggingAspect {
	private Object principal;
	private String user;

	Logger logger = LoggerFactory.getLogger(SpringAUthApplication.class);

	@Before("execution(public String showLogin())")
	public void LoggingBforeAdvice() {
		System.out.println("Advice run. The showLogin method is called");
		 logger.info("The Advice Get method is called.");
	}

	@After("execution(public String showLogin())")
	public void LoggingAfterAdvice() {
		principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof MyUserDetails) {
			System.out.println("userdetails is" + ((MyUserDetails) principal).getUsername());
			user = ((UserDetails) principal).getUsername();
		} else {
			System.out.println("userdetails2 is" + principal.toString());
			user = principal.toString();
		}
		System.out.println("Advice run. The showLogin method is called by" + user);
		 logger.info("The Advice for showLogin method has been called.");

	}

}
