package com.hresource.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hresource.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("SELECT e FROM Employee e join Department d on e.department = d.id WHERE CONCAT(e.id, e.name, e.tel, e.gender,e.salary, e.email, d.name) LIKE %?1%")
    public Page<Employee> findAll(String keyword,Pageable pageable);
}
