Can use

username: admin or hr or counter
password: pass

https://cheongssemployeecp6.herokuapp.com/

admin = administrator
hr = human resource staff
counter = counter clerks 