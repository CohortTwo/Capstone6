package com.ntuc.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ntuc.model.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer> {

	
	@Query(value = "select BDATE from BOOKING", nativeQuery = true)
    Date[] showDates();
	
	
}
