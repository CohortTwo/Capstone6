package com.ntuc.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ntuc.model.Room;

public interface RoomRepository extends JpaRepository<Room, Integer> {
	
	@Query("SELECT r FROM Room r WHERE "
			+ " CONCAT(r.id, r.roomtype.name, r.price, r.name)" 
			+  " LIKE %?1%" )
	public Page<Room> findAll(String keyword,Pageable pageable);
	
	@Query("SELECT r FROM Room r WHERE r.id = :id")
	public Room getRoom(@Param("id") Integer id);
	
}
