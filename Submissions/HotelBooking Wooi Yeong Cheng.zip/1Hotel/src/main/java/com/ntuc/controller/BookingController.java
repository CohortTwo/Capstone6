package com.ntuc.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ntuc.model.Booking;
import com.ntuc.model.Room;
import com.ntuc.repository.BookingRepository;
import com.ntuc.repository.RoomRepository;

@Controller
public class BookingController {

	@Autowired
	private BookingRepository bookRepo;

	@Autowired
	private RoomRepository roomRepo;

	@GetMapping("/books")
	public String listBook(Model model) {			
		Date[] listdates = bookRepo.showDates();
		model.addAttribute("listdates", listdates);
		List<Booking> listbook = bookRepo.findAll();
		model.addAttribute("listbook", listbook);
		return "books";
	}

	@GetMapping("/books/new/{id}")
	public String ShowBookform(@PathVariable("id") Integer id, Model model) {
		Room listroom = roomRepo.findById(id).get();

		Booking bd = new Booking();
		Date[] listdates = bookRepo.showDates();

		String[] finalDates = new String[listdates.length];
		SimpleDateFormat b = new SimpleDateFormat("d-m-yyyy");
		for (int i = 0; i < listdates.length; i++) {
			finalDates[i] = b.format(listdates[i]);
		}

		model.addAttribute("finalDates", finalDates);
		model.addAttribute("bd", bd);
		model.addAttribute("listroom", listroom);
		model.addAttribute("Booking", new Booking());
		return "book_form";
	}

	@PostMapping("/books/save")
	public String saveBook(Booking booking) {
		bookRepo.save(booking);
		return "redirect:/books";
	}


}
