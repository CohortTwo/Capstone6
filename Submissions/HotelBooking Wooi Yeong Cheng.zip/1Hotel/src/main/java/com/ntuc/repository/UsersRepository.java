package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ntuc.model.Users;

public interface UsersRepository extends JpaRepository<Users, Long>{

}
