package com.ntuc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


import com.ntuc.model.RoomType;
import com.ntuc.repository.RoomTypeRepository;

@Controller
public class RoomTypeController {
	
	@Autowired
	private RoomTypeRepository roomtypeRepo;
		
	@GetMapping("/roomtype")
	public String listRoomType(Model model) {
		List<RoomType> listroomtype = roomtypeRepo.findAll();
		model.addAttribute("listroomtype",listroomtype);
		return "roomtype";	
	}	
	@GetMapping("/roomtype/new")
	public String ShowRoomTypeform(Model model) {
			
		model.addAttribute("RoomType", new RoomType());
		return "roomtype_form";
	}
		
	@PostMapping("/roomtype/save")
	public String saveRoom(RoomType roomtype) {
		roomtypeRepo.save(roomtype);
		return "redirect:/roomtype";
	}		
	
}
