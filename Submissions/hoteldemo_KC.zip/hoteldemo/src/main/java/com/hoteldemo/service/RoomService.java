package com.hoteldemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hoteldemo.domain.Bed;
import com.hoteldemo.domain.Room;
import com.hoteldemo.domain.RoomLevel;
import com.hoteldemo.domain.RoomNumber;
import com.hoteldemo.domain.RoomType;
import com.hoteldemo.repo.RoomRepository;

@Service
public class RoomService {
	
	@Autowired
	private RoomRepository roomRepository;
	
	@Transactional
	public void addGuestToRoom(RoomLevel roomLevel, RoomNumber roomNumber, Bed bed, RoomType roomType) {
		Room room = new Room();
		room.setBed(bed);
		room.setRoomLevel(roomLevel);
		room.setRoomNumber(roomNumber);
		room.setRoomType(roomType);
		
		roomRepository.save(room);
	}

}
