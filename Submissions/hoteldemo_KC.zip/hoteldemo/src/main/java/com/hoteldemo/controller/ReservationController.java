package com.hoteldemo.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import com.hoteldemo.domain.Bed;
import com.hoteldemo.domain.Guest;
import com.hoteldemo.domain.ReservationDate;
import com.hoteldemo.domain.Room;
import com.hoteldemo.domain.RoomLevel;
import com.hoteldemo.domain.RoomNumber;
import com.hoteldemo.domain.RoomType;
import com.hoteldemo.repo.DateRepository;
import com.hoteldemo.repo.GuestRepository;
import com.hoteldemo.repo.ReservationRepository;
import com.hoteldemo.repo.RoomRepository;
import com.hoteldemo.service.ReservationService;

@Controller
public class ReservationController {
	
	@Autowired
	private DateRepository dateRepo;
	
	@Autowired
	private RoomRepository roomRepo;
	
	@Autowired
	private GuestRepository guestRepo;
	
	@Autowired
	private ReservationService reservationService;
	
	@Autowired
	private ReservationRepository reservationRepo;
	
	@PostMapping("/confirmation")
	public String saveReservation(HttpSession session, 
			String firstName, 
			String lastName, 
			String checkOutDate, 
			String checkInDate, 
			String name, 
			String roomType,
			String roomLevel, 
			String roomNumber, 
			String bed) {
		
		Guest guest = new Guest();
		String custfirstName = (String) session.getAttribute("firstName");
		System.out.println(custfirstName);
		String custlastName = (String) session.getAttribute("lastName");
		guest.setFirstName(custfirstName);
		guest.setLastName(custlastName);
		guestRepo.saveAndFlush(guest);
		
		ReservationDate rDate = new ReservationDate();
		String chkOutDate = (String) session.getAttribute("checkOutDate");
		String chkInDate = (String) session.getAttribute("checkInDate");
		LocalDate cid = LocalDate.parse(chkInDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		LocalDate cod = LocalDate.parse(chkOutDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		rDate.setCheckInDate(cid);
		rDate.setCheckOutDate(cod);
		dateRepo.saveAndFlush(rDate);
		
		Room rRoom = new Room();
		RoomType rRoomType = (RoomType) session.getAttribute("roomType");
		RoomLevel rRoomLevel = (RoomLevel) session.getAttribute("roomLevel");
		RoomNumber rRoomNumber = (RoomNumber) session.getAttribute("roomNumber");
		Bed rBed = (Bed) session.getAttribute("bed");
		rRoom.setRoomType(rRoomType);
		rRoom.setRoomLevel(rRoomLevel);
		rRoom.setRoomNumber(rRoomNumber);
		rRoom.setBed(rBed);
		roomRepo.saveAndFlush(rRoom);
	
		reservationService.saveReservation(guest, rDate, rRoom);
		System.out.println("test");
		
		return "redirect:/";
	}
}
