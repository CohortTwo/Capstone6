package com.hoteldemo.domain;

public enum Bed {
	One, Two
}
