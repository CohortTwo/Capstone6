package com.hoteldemo.domain;

public enum RoomNumber {
	One, Two, Three, Four, Five, Six
}
