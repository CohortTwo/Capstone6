package com.hoteldemo.domain;

public enum RoomType {
	Standard, Deluxe, Business, Presidential
}
