package com.hoteldemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hoteldemo.domain.Guest;
import com.hoteldemo.repo.GuestRepository;

@Service
public class GuestService {

	@Autowired
	private GuestRepository guestRepository;
	
	public Guest createNewGuestDetails(String firstName, String lastName) {
		Guest guest = new Guest();
		guest.setFirstName(firstName);
		guest.setLastName(lastName);
		return guestRepository.saveAndFlush(guest);
	}
}
