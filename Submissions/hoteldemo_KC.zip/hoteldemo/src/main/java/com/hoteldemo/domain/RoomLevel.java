package com.hoteldemo.domain;

public enum RoomLevel {
	One, Two, Three
}
