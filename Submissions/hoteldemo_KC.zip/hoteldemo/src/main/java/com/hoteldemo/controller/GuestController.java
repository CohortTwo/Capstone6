package com.hoteldemo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hoteldemo.service.GuestService;

@Controller
public class GuestController {

	@Autowired
	private GuestService guestService;
	
	@PostMapping("/guest")
	public String saveGuestDetails(
			HttpSession session,
			@RequestParam("firstName") String firstName,
			@RequestParam("lastName") String lastName
			) {
		guestService.createNewGuestDetails(firstName, lastName);
		session.setAttribute("firstName", firstName);
		session.setAttribute("lastName", lastName);
		System.out.println("check " + " " + firstName + " " + lastName);
		return "confirmation";
	}
}
