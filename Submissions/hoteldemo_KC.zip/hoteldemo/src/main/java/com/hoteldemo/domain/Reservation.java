package com.hoteldemo.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Reservation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@ManyToOne
	private ReservationDate reservationDate;
	
	@ManyToOne
	private Guest guest;
	
	@OneToOne
	private Room room;

	public Reservation(Long id, ReservationDate reservationDate, Guest guest, Room room) {
		super();
		this.id = id;
		this.reservationDate = reservationDate;
		this.guest = guest;
		this.room = room;
	}
	
	public Reservation() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ReservationDate getReservationDate() {
		return reservationDate;
	}

	public void setReservationDate(ReservationDate reservationDate) {
		this.reservationDate = reservationDate;
	}

	public Guest getGuest() {
		return guest;
	}

	public void setGuest(Guest guest) {
		this.guest = guest;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}
	
}
