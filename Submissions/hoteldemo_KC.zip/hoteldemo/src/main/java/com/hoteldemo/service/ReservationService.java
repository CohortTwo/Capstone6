package com.hoteldemo.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hoteldemo.domain.Guest;
import com.hoteldemo.domain.Reservation;
import com.hoteldemo.domain.ReservationDate;
import com.hoteldemo.domain.Room;
import com.hoteldemo.repo.ReservationRepository;

@Service
public class ReservationService {

	@Autowired
	private ReservationRepository reservationRepository;

	@Transactional
	public BigDecimal sumTotalCost(BigDecimal costPerNight, BigDecimal totalCost) {
		ReservationDate reservationDate = new ReservationDate();
		Long totalNight = reservationDate.totalNights();
		return totalCost = costPerNight.multiply(BigDecimal.valueOf(totalNight));
	}
	
	@Transactional
	public void saveReservation(Guest guest, ReservationDate reservationDate, Room room) {
		Reservation reservation = new Reservation();
		reservation.setGuest(guest);
		reservation.setReservationDate(reservationDate);
		reservation.setRoom(room);
		reservationRepository.save(reservation);
	}
	
}
