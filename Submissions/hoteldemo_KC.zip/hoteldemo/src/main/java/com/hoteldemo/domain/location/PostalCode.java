package com.hoteldemo.domain.location;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Embeddable
public class PostalCode {
	@Column(nullable = false)
	@Pattern(regexp = "[0-9]{6}", message = "Postal code must be 6 digits")
	@NotNull(message = "required")
	private String value;

	public PostalCode(String value) {
		this.value = value;
	}

	public PostalCode() {
		super();
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PostalCode other = (PostalCode) obj;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PostalCode [value=" + value + "]";
	}
	
	
	
}
