package com.hoteldemo.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hoteldemo.domain.ReservationDate;
import com.hoteldemo.repo.DateRepository;

@Service
public class DateService {
	
	@Autowired
	private DateRepository dateRepo;
	
	//Method to save check in and check out date
	@Transactional
	public ReservationDate createNewReservationDate(LocalDate checkInDate, LocalDate checkOutDate) {
		ReservationDate rd = new ReservationDate();
		rd.setCheckInDate(checkInDate);
		rd.setCheckOutDate(checkOutDate);
		
		return dateRepo.saveAndFlush(rd);
	}
	
	//Converting String to LocalDate
	@Transactional
	public ReservationDate createNewReservationDate(String checkInDate, String checkOutDate) {
		LocalDate cid = LocalDate.parse(checkInDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		LocalDate cod = LocalDate.parse(checkOutDate, DateTimeFormatter.ofPattern("MM/dd/yyyy"));
		return createNewReservationDate(cid,cod);
	}
	
}
