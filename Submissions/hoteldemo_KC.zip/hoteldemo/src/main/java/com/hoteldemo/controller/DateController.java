package com.hoteldemo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value="/")
public class DateController {
	
	@GetMapping("/dates")
	public String showDates() {
		return "date";
	}

	@PostMapping(value = "/dates/1")
	public String saveDatesSession(
			HttpSession session,
			@RequestParam("checkInDate") String checkInDate,
			@RequestParam("checkOutDate") String checkOutDate
			) {
		System.out.println("RANDOM");
		session.setAttribute("checkInDate", checkInDate);
		session.setAttribute("checkOutDate", checkOutDate);
		System.out.println("check dates added: " + " " + checkInDate + " " + checkOutDate);
		return "room";
	}
}
