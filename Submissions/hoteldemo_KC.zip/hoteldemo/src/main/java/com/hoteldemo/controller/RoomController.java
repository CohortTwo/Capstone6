package com.hoteldemo.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hoteldemo.domain.Bed;
import com.hoteldemo.domain.Room;
import com.hoteldemo.domain.RoomLevel;
import com.hoteldemo.domain.RoomNumber;
import com.hoteldemo.domain.RoomType;

@Controller
public class RoomController {
	
	@GetMapping("/rooms")
	public String showRooms(Model model) {
		model.addAttribute("room", new Room());
		return "room";
	}
	
	@PostMapping("/rooms")
	public String saveRoomSession(@RequestParam("roomType") RoomType roomType,
			HttpSession session) {
		session.setAttribute("roomType", roomType);
		System.out.println(roomType);
		return "roomselection";
	}
	
	@PostMapping("/select/room")
	public String saveRoomSession(
			@RequestParam("roomLevel") RoomLevel roomLevel,
			@RequestParam("roomNumber") RoomNumber roomNumber,
			@RequestParam("bed") Bed bed,
			HttpSession session) {
		session.setAttribute("roomLevel", roomLevel);
		session.setAttribute("roomNumber", roomNumber);
		session.setAttribute("bed", bed);
		System.out.println("room level: " + roomLevel);
		System.out.println("room number: " + roomNumber);
		System.out.println("bed : " + bed);
		return "guest";
	}
}
