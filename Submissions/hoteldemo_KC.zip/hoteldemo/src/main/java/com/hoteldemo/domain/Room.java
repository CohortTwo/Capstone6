package com.hoteldemo.domain;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Enumerated(EnumType.STRING)
	private RoomLevel roomLevel;
	
	@Enumerated(EnumType.STRING)
	private RoomNumber roomNumber;
	
	@Enumerated(EnumType.STRING)
	private Bed bed;
	
	@Enumerated(EnumType.STRING)
	private RoomType roomType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RoomLevel getRoomLevel() {
		return roomLevel;
	}

	public void setRoomLevel(RoomLevel roomLevel) {
		this.roomLevel = roomLevel;
	}

	public RoomNumber getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(RoomNumber roomNumber) {
		this.roomNumber = roomNumber;
	}

	public Bed getBed() {
		return bed;
	}

	public void setBed(Bed bed) {
		this.bed = bed;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bed == null) ? 0 : bed.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((roomLevel == null) ? 0 : roomLevel.hashCode());
		result = prime * result + ((roomNumber == null) ? 0 : roomNumber.hashCode());
		result = prime * result + ((roomType == null) ? 0 : roomType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Room other = (Room) obj;
		if (bed != other.bed)
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (roomLevel != other.roomLevel)
			return false;
		if (roomNumber != other.roomNumber)
			return false;
		if (roomType != other.roomType)
			return false;
		return true;
	}

	public Room(Long id, RoomLevel roomLevel, RoomNumber roomNumber, Bed bed, RoomType roomType) {
		super();
		this.id = id;
		this.roomLevel = roomLevel;
		this.roomNumber = roomNumber;
		this.bed = bed;
		this.roomType = roomType;
	}

	public Room() {
		super();
	}	
	
}
