package com.hoteldemo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hoteldemo.domain.ReservationDate;

public interface DateRepository extends JpaRepository<ReservationDate, Long> {
	@Query(value = "select * from Dates", nativeQuery = true)
	List<ReservationDate> showDates();
}
