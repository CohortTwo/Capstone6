package com.ntuc.repository;






import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.ntuc.model.booked;

@Repository
public interface BookedRepository extends JpaRepository<booked, Integer> {
}
