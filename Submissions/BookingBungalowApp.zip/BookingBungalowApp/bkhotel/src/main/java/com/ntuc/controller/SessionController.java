package com.ntuc.controller;


import java.util.Date;
import java.util.List;
import com.ntuc.model.booked;



import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import javax.servlet.http.HttpSession;


import org.springframework.web.bind.annotation.RequestParam;

import com.ntuc.model.booked;
import com.ntuc.repository.BookedRepository;

@Controller
public class SessionController {
	
	@Autowired BookedRepository repo;
	
	@GetMapping("/")
	public String ShowFirst(HttpSession session) {
		Object date=new Date();
		String test = "Welcome to the Booking Page";
		session.setAttribute("today", date);
		session.setAttribute("test", test);
		return "index";
	}
	
	@GetMapping("/page1")
	public String NextPage() {
		return "page1";
	}
	
	@GetMapping("/page2")
	public String OneMorePage(Model model, @RequestParam("p2") Integer p1, HttpSession session) {
		List<booked> listdays = repo.findAll();
		
		int newflag =0;
		String msg ="Regrets, Bungalow is unavailable on April, ";
		
		  for (int i=0 ;i<listdays.size(); i++) {
				/*
				 * System.out.println("Day p1:"+ p1 );
				 * System.out.println("before -Day in database : "+listdays.get(i).getDay());
				 */
			  if (listdays.get(i).getDay()== p1) {
				  newflag =1;
				  }
			 
		  }
			/* System.out.println("newflag: "+newflag); */
		if (newflag ==0) {
			
			booked nbking =new booked();
			/*
			 * int id1 =1; nbking.setId(id1);; nbking.setDay(p1);
			 */
			nbking.setId(p1);
			nbking.setDay(p1);
			
			/*
			 * System.out.println("what is inside nbking.getId: "+nbking.getId());
			 * System.out.println("what is inside nbking.getDay: "+nbking.getDay());
			 */
			
			repo.save(nbking);
			msg ="We will reserve the Bungalow for you on April, ";
			//save database
		}
		
		session.setAttribute("msg", msg);
		session.setAttribute("p1", p1);
	
		
		return "page2";
	}

}
