package com.ntuc.controller;

import com.ntuc.repository.JdbcJobRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class JobController {
	@Autowired
	private JdbcJobRepository repo;
	
	@ModelAttribute("listJobs")
	public void listJobs(Model model) {
		model.addAttribute("listJobs", repo.findAll());
	}
}
