package com.ntuc;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	DataSource dataSource;

	@Override 
	public void configure(AuthenticationManagerBuilder auth) 
		throws Exception {

		JdbcUserDetailsManager jdbcUserDetailsService = new JdbcUserDetailsManager(dataSource);

		String authsByUserQuery = 
			"select u.username, r.name " +
			"from users_roles as ur " +
			"join users as u on u.user_id=ur.user_id " +
			"join roles as r on r.role_id=ur.role_id " +
			"where username = ?";

		jdbcUserDetailsService.setAuthoritiesByUsernameQuery(authsByUserQuery);

		// You can remove the passwordEncoder() method and set up the the
		// password encoder as a @Bean. But it is better if you do not mix
		// the two methods.
		auth.userDetailsService(jdbcUserDetailsService)
			.passwordEncoder(new BCryptPasswordEncoder());
	}


	/*
	@Override 
	protected void configure(AuthenticationManagerBuilder auth) 
		throws Exception {

		auth.inMemoryAuthentication()
			.withUser("andy")
			.password("{noop}andy")
			.roles("USER")
		.and()
			.withUser("admin")
			.password("{noop}admin")
			.roles("USER", "ADMIN");
	}
	*/

	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers(
				"/resources/**", 
				"/css/**",
				"/images/**", 
				"/fonts/**", 
				"/icon/**",
				"/vendor/**");
	}

	@Override 
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			.anyRequest().authenticated()
		.and()
			.formLogin().loginPage("/loginpage").permitAll()
			.loginProcessingUrl("/authenticate").permitAll()
			.defaultSuccessUrl("/", true)
		.and()
			.logout()
				.invalidateHttpSession(true)
				.deleteCookies("JSESSIONID")
				.logoutRequestMatcher(new AntPathRequestMatcher("/applogout"))
				.logoutSuccessUrl("/loginpage")
				.permitAll();

				// .logoutUrl just won't work have to resort to logoutRequestMatcher
				// .logoutUrl("/applogout")  
	}
}
