package com.ntuc.controller;

import com.ntuc.repository.BasicRepository;
import com.ntuc.repository.JdbcDepartmentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class DepartmentController {
	@Autowired
	private JdbcDepartmentRepository repo;

	@ModelAttribute("listDepartments")
	public void listDepartments(Model model) {
		model.addAttribute("listDepartments", repo.findAll());
	}

}
