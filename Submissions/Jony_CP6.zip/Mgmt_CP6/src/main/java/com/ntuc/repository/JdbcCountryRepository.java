package com.ntuc.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class JdbcCountryRepository 
	implements BasicRepository<HashMap<String, String>> {

	private JdbcTemplate jdbc;

	// @Autowired // Isn't require because Spring automatically does the wiring
	public JdbcCountryRepository(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	@Transactional
	public List<HashMap<String, String>> findAll() {
		return jdbc.query("select country_id, country_name from countries", 
				(rs, rowNum) ->  new HashMap<String, String>() {{
					put("countryId", rs.getString("country_id"));
					put("countryName", rs.getString("country_name"));
				}});
	}

	/*
	private HashMap<String, String> mapRowToCountry(ResultSet rs, int rowNum) 
		throws SQLException {

		var result = new HashMap<String, String>();
		result.put("countryId", rs.getString("country_id"));
		result.put("countryName", rs.getString("country_name"));
		return result;
	}
	*/
}
