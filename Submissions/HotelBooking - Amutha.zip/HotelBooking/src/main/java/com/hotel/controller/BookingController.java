package com.hotel.controller;

import java.util.Date;
import java.io.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hotel.HotelBook;
import com.hotel.HotelRepository;
import com.hotel.HotelService;


@Controller
public class BookingController {
	
	@Autowired
	private HotelService service;
	@Autowired
	private HotelRepository repo;
	
	@GetMapping(" ")
	public String ShowFirst(HttpSession session) {
		Object date=new Date();
		session.setAttribute("today", date);
		return "index";
	}
	
	@GetMapping("/page")
	public String OneMorePage(@RequestParam("hotelname") String s1,
			@RequestParam("roomtype") String s2, 
			@RequestParam("noofdays") String s3,  HttpSession session) {
		System.out.println("I am in session function");
		session.setAttribute("s1", s1);
		session.setAttribute("s2", s2);
		session.setAttribute("s3", s3);
		return "page";
	}
	
	
	@RequestMapping(value ="/save", method = RequestMethod.POST) 
	@ResponseBody
	public String saveHotel(@RequestParam("hotelname") String s1,
			@RequestParam("roomtype") String s2, 
			@RequestParam("noofdays") Integer s3, HttpSession session, Model model) {
		System.out.println("I am in save function");
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3); 
		HotelBook myhotel = new HotelBook();
		myhotel.setHotelname(s1);
		myhotel.setRoomtype(s2); 
		myhotel.setNoofdays(s3);
		repo.save(myhotel);
		return "Record Added";
		
	}
	
	 
	/*
	 * @PostMapping("/save") public String saveBooking(HotelBook hotelbook,
	 * HttpServletRequest request, HttpSession session) { repo.save(hotelbook);
	 * return "save"; }
	 */
	 	
}
