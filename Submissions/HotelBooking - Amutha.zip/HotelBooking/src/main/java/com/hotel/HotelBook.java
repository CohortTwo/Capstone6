package com.hotel;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class HotelBook {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer bookid;
	private String hotelname;
	private String roomtype;
	private Integer noofdays;
	
	
public Integer getBookid() {
		return bookid;
	}


	public void setBookid(Integer bookid) {
		this.bookid = bookid;
	}


	public String getHotelname() {
		return hotelname;
	}


	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}


	public String getRoomtype() {
		return roomtype;
	}


	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}


	public Integer getNoofdays() {
		return noofdays;
	}


	public void setNoofdays(Integer noofdays) {
		this.noofdays = noofdays;
	}


public HotelBook(Integer bookid, String hotelname, String roomtype, Integer noofdays) {
		
		this.bookid = bookid;
		this.hotelname = hotelname;
		this.roomtype = roomtype;
		this.noofdays = noofdays;
	}


public HotelBook() {
		
	}
	
}
