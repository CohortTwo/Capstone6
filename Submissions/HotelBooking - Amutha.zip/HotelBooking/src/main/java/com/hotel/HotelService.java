package com.hotel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotel.HotelRepository;
import com.hotel.HotelBook;

@Service
public class HotelService {

	@Autowired
	private HotelRepository repo;
	
	public void saveHotel(HotelBook hotelbook) {
		repo.save(hotelbook);
	}
	
}
