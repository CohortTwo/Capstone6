package com.ntuc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGoogleChartsExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGoogleChartsExampleApplication.class, args);
	}
}