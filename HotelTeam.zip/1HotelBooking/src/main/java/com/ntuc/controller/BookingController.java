package com.ntuc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ntuc.model.Booking;
import com.ntuc.repository.BookingRepository;


@Controller
public class BookingController {

	
	
	
		@Autowired
		private BookingRepository bookRepo;
		
		@GetMapping("/bookings")
		public String listbooking(Model model) {
			List<Booking> listbooking = bookRepo.findAll();
			model.addAttribute("listbooking",listbooking);
			return "bookings";
		}
}
