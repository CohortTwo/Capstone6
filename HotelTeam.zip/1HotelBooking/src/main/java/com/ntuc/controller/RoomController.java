package com.ntuc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ntuc.model.Room;
import com.ntuc.repository.RoomRepository;



@Controller
public class RoomController {
	
	@Autowired
	private RoomRepository roomRepo;
	
	@GetMapping("/rooms")
	public String listRoom(Model model) {
		List<Room> listroom = roomRepo.findAll();
		model.addAttribute("listroom",listroom);
		return "rooms";
	}
	
	@GetMapping("/rooms/new")
	public String ShowRoomform(Model model) {
				
		model.addAttribute("Room", new Room());
		return "room_form";
	}
	
	
	@PostMapping("/rooms/save")
	public String saveRoom(Room room) {
		roomRepo.save(room);
		return "redirect:/rooms";
	}
	
	
	
	
}
