package com.ntuc.model;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Room {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(length = 45, nullable = false, unique=true)
	private String name;
	
	private float price;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate checkin;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate checkout;
	/* private Boolean available; */
	

	public long totalNights() {
		if (checkin ==null || checkout == null) {
			return 0;
		} return ChronoUnit.DAYS.between(checkin, checkout);
	}
	
	public LocalDate getCheckin() {
		return checkin;
	}

	public void setCheckin(LocalDate checkin) {
		this.checkin = checkin;
	}

	public LocalDate getCheckout() {
		return checkout;
	}

	public void setCheckout(LocalDate checkout) {
		this.checkout = checkout;
	}

	/*
	 * public Boolean getAvailable() { return available; }
	 * 
	 * public void setAvailable(Boolean available) { this.available = available; }
	 */

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	
	
	
}
