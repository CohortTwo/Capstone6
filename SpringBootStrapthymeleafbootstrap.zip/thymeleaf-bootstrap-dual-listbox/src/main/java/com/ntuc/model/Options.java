package com.ntuc.model;

import java.util.List;


public class Options {

    private List<String> selected;

	public List<String> getSelected() {
		return selected;
	}

	public void setSelected(List<String> selected) {
		this.selected = selected;
	}

	public Options() {
		super();
	}
    
    
    
}
