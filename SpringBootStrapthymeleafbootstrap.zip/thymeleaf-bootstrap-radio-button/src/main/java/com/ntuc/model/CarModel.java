package com.ntuc.model;

public enum CarModel {

    VW,
    SUZUKI,
    DODGE,
    VOLVO

}
