package com.ntuc.model;

public class Car {

    private CarModel carModel;
    private int option;
	public CarModel getCarModel() {
		return carModel;
	}
	public void setCarModel(CarModel carModel) {
		this.carModel = carModel;
	}
	public int getOption() {
		return option;
	}
	public void setOption(int option) {
		this.option = option;
	}
	public Car() {
		super();
	}
    
    

}
