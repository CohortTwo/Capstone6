package com.ntuc.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.ntuc.SpringBootAopApplication;

@Component
@Aspect
public class LoggingAspect {

	Logger logger = LoggerFactory.getLogger(SpringBootAopApplication.class);

	@Before("execution(public String showIndex())")
	public void LoggingBforeAdvice() {
		System.out.println("Advice run. The showIndex method is called");
		 logger.info("The Advice Get method has been called.");
	}

	@After("execution(public String showIndex())")
	public void LoggingAfterAdvice() {
		 logger.info("The Advice for showindex method has been called.");

	}

}
