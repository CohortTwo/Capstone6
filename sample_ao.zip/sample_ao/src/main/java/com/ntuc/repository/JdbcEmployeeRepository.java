
package com.ntuc.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;

import com.ntuc.model.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
import org.springframework.stereotype.Repository;


@Repository
public class JdbcEmployeeRepository 
	implements GeneralRepository<Employee> {

	private JdbcTemplate jdbc;
	
	@Autowired
	public JdbcEmployeeRepository(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public List<Employee> findAll() {
		return jdbc.query("select * from employees",
				this::mapRowToEmployee);
	}

	public List<Employee> findAll(Order order) {
		String sortBy = order.getProperty();
		String sortDir = order.getDirection().toString();
		String sql = String.format("select * from employees order by %s %s", sortBy, sortDir);
		return jdbc.query(sql, this::mapRowToEmployee); 

	}

	@Override 
	public Employee findOne(Integer employeeId) {
		return jdbc.queryForObject(
				"select * from employees where employee_id=?", 
				this::mapRowToEmployee, employeeId);
	}

	private Employee mapRowToEmployee(ResultSet rs, int rowNum) 
		throws SQLException {

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		return new Employee(
				rs.getInt("employee_id"),
				rs.getString("first_name"),
				rs.getString("last_name"),
				rs.getString("email"),
				rs.getString("phone_number"),
				LocalDate.parse(formatter.format(rs.getDate("hire_date"))),
				rs.getInt("job_id"),
				rs.getBigDecimal("salary"),
				rs.getInt("manager_id"),
				rs.getInt("department_id"));
	}

	@Override 
	public Employee save(Employee employee) {
		String sql = "insert into employees " +
			"(employee_id, first_name, last_name, email, phone_number, " + "hire_date, job_id, salary, manager_id, department_id) " +
			"values (?,?,?,?,?,?,?,?,?,?)";
		jdbc.update(sql, 
				employee.getEmployeeId(),
				employee.getFirstName(),
				employee.getLastName(), 
				employee.getEmail(), 
				employee.getPhoneNumber(),
				employee.getHireDate(), 
				employee.getJobId(), 
				employee.getSalary(), 
				employee.getManager_id(), 
				employee.getDepartment_id());
		return employee;
	}

	@Override
	public void deleteById(Integer employeeId) {
		jdbc.update("DELETE FROM employees WHERE employee_id=?", employeeId);
	}

	@Override
	public Employee update(Employee employee) {

		String sql = "update employees " +
			"SET " +
			" first_name=?, " +
			" last_name=?, " + 
			" email=?, " +
			" phone_number=?, " +
			" hire_date=?, " +
			" job_id=?, " +
			" salary=?, " +
			" manager_id=?, " +
			" department_id=? " + 
			" where employee_id=? ";
		jdbc.update(sql, 
				employee.getFirstName(),
				employee.getLastName(), 
				employee.getEmail(), 
				employee.getPhoneNumber(),
				employee.getHireDate(), 
				employee.getJobId(), 
				employee.getSalary(), 
				employee.getManager_id(), 
				employee.getDepartment_id(), 
				employee.getEmployeeId());
		return employee;
	}
}
