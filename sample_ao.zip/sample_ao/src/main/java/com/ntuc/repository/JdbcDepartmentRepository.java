package com.ntuc.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.ntuc.model.Department;
import com.ntuc.model.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JdbcDepartmentRepository 
	implements BasicRepository<Department> {

	private JdbcTemplate jdbc;

	@Autowired
	public JdbcDepartmentRepository(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override
	public List<Department> findAll() {
		return jdbc.query("select * from departments",
				this::mapRowToDepartment);
	}

	private Department mapRowToDepartment(ResultSet rs, int rowNum) 
		throws SQLException {

		return new Department(
				rs.getInt("department_id"),
				rs.getString("department_name"),
				rs.getInt("location_id"));
	}
}
