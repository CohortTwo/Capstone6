package com.ntuc.repository;

import java.util.List;

public interface BasicRepository<T> {
	List<T> findAll();
}
