package com.ntuc.controller;

import java.util.List;

import com.ntuc.model.Employee;
import com.ntuc.model.Job;
import com.ntuc.repository.GeneralRepository;
import com.ntuc.repository.JdbcEmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EmployeeController {
	@Autowired
	private JdbcEmployeeRepository repo;

	@GetMapping("/employees")
	public String listEmployees(Model model) {
		List<Employee> listEmployees = repo.findAll();
		model.addAttribute("listEmployees",listEmployees);
		return "employees";
	}

	@GetMapping("/employees/lastname_desc")
	public String listEmployeesSortByLastNameDesc(Model model) {
		Order order = Order.desc("last_name");
		List<Employee> listEmployees = repo.findAll(order);
		model.addAttribute("listEmployees",listEmployees);
		return "employees";
	}

	@GetMapping("/employees/new")
	public String showNewEmployeeForm(Model model) {
		model.addAttribute("employee", new Employee());
		return "employee_form";
	}

	@PostMapping("/employees/save")
	public String saveEmployee(Employee employee) {
		repo.save(employee);
		return "redirect:/employees";
	}

	@PostMapping("/employees/update")
	public String updateEmployee(Employee employee) {
		repo.update(employee);
		return "redirect:/employees";
	}

	@GetMapping("/employees/delete/{id}")
	public String showDeleteEmployeeForm(
			@PathVariable("id") Integer employeeId, Model model) {
		repo.deleteById(employeeId);
		return "redirect:/employees";
	}

	@GetMapping("/employees/edit/{id}")
	public String showEditEmployeForm(
			@PathVariable("id") Integer employeeId, Model model) {
		Employee employee = repo.findOne(employeeId);
		model.addAttribute("employee", employee);
		return "employee_edit_form";
	}
}
